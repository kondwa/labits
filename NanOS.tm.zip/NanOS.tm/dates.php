<style type="text/css">
	.month{
		display:inline-block;
		border: 1px solid #eee;
		padding: 3px;
		margin: 1px;
	}
	.month caption{
		border:1px solid #aaa;
		background-color: #eee;
	}
	.month td{
		border: 1px solid #eee;
		text-align: right;
		width: 1.1em;
		height: 1.1em;
		padding: 1px;
		margin: 1px;
	}
	.month td:hover{
		background-color: #aaa;
	}
</style>

<?php
	$weekdays = 7;
	$monthweeks = 4;
	$yearmonths = 13;
	$monthnames = array(
		"first", "second", "third", "fourth",
		"fifth", "sixth", "seventh", "eighth",
		"nineth", "tenth","eleventh","twelveth",
		"thirteenth"
	);
?>
<div align="center">
<?php for($month = 1; $month <= $yearmonths; $month++): ?>
<table class="month">
	<?php $daycount = 1; ?>
	<caption> <?php echo $monthnames[$month-1]; ?> </caption>
	<?php for($week=1; $week <= $monthweeks; $week++): ?>
	<tr>
		<?php for($day = 1; $day <= $weekdays; $day++): ?>
		<td><a><?php echo $daycount++; ?></a></td>
		<?php endfor; ?>
	</tr>
	<?php endfor; ?>
</table>
<?php endfor; ?>
</div>