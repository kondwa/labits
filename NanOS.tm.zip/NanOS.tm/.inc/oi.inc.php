<?php

class SessionData{
    /* Oisp® SessionData. */
    public function __set($variable,$value){
        session_start();
        $_SESSION[$variable] = $value;
        session_commit();
    }
    public function __get($variable){
        session_start();
        $value = ( isset($_SESSION[$variable]) )? 
            $_SESSION[$variable] : NULL;
        session_commit();
        return $value; 
    }
    static function clean(){
        session_start();
        $_SESSION = array();
        session_commit();
    }
}

$SD = new SessionData();

$SD->name = "K. Hara. MSc, BSc. ";

echo $SD->name;
$SD->clean();
echo $SD->name;

?>