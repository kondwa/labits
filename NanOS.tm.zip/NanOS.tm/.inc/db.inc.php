<?php
try{
	$DB = new PDO("sqlite:db.sqlite");
}catch(Exception $e){
	echo $e->getMessage();
}

$a=$DB->prepare(
"CREATE TABLE IF NOT EXISTS `account`(
	`id` INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
);");
$p=$DB->prepare(
"CREATE TABLE IF NOT EXISTS `person`(
	`id` INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
);");
$t=$DB->prepare("CREATE IF NOT EXISTS `transaction`(
	`id` INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
);");
?>