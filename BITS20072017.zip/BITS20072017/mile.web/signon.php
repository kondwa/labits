<?php 
if($data=$_POST):
    signin($data);
else:
?>
<form method="post">
    <fieldset>
        <legend>Sign in</legend>
        <label>
            Username:
            <input type="text" name="uname" required="true"/>
        </label>
        <label>
            Password:
            <input type="password" name="password" required="true" />
        </label>
        <input type="submit" value="Sign in" />
    </fieldset>
</form>
<?php endif; ?>