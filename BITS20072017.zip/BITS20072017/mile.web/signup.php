<?php
	if($data=$_POST){
		signup($data);
	}else{
?>
<form method="post">
	<fieldset>
		<legend>Sign up</legend>
		<label>
			First name:
			<input type="text" name="fname" required="true" />
		</label>
		<label>
			Last name:
			<input type="text" name="lname" required="true" />
		</label>
		<label>
			Username:
			<input type="text" name="uname" required="true" />
		</label>
		<label>
			Password:
			<input type="password" name="password" required="true" />
		</label>
		<input type="submit" value="Sign up" />
	</fieldset>
</form>
<?php } ?>