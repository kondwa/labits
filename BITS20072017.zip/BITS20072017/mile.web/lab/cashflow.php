<?php echo "cashflow."; ?>

<?php
    function money($n){return number_format($n,2,'.',','); }
    $db=new PDO("sqlite:data.sqlite");
    $sth = $db->prepare("SELECT * FROM `cashflow`");
    $sth->execute();
    $amount = 0;
?>
<table border="1px">
    <thead>
        <th>Date</th>
        <th>Description</th>
        <th>Deposit</th>
        <th>Withdraw</th>
        <th>Balance</th>
    </thead>

    <?php while($row=$sth->fetch()): ?>
    <?php $amount = bcsub($amount,$row['CashflowWithdraw']); ?>
    <?php $amount = bcadd($amount,$row['CashflowDeposit']); ?>
    <tr>
        <td><?php echo $row['CashflowDate']; ?></td>
        <td><?php echo $row['CashflowDesc']; ?></td>
        <td><?php echo "K".money($row['CashflowDeposit']); ?></td>
        <td><?php echo "K".money($row['CashflowWithdraw']); ?></td>
        <td><?php echo "K".money($amount); ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<?php echo "Account Balance = K" . $amount;  