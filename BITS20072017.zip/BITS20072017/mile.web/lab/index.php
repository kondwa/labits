<?php echo "php lab."; ?>

<?php include("init.php");?>