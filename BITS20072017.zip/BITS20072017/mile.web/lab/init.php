<?php echo "init database."; ?>

<?php
$db = new PDO("sqlite:data.sqlite");
$cashflow = $db->prepare(
	"CREATE TABLE IF NOT EXISTS `Cashflow`(
			`CashflowID` INTEGER PRIMARY KEY AUTOINCREMENT,
			`CashflowDate` DATE,
			`CashflowDesc` TEXT,
			`CashflowDeposit` NUMERIC,
			`CashflowWithdraw` NUMERIC
	);");
$cashflow->execute();
$balancesheet = $db->prepare(
	"CREATE TABLE IF NOT EXISTS `BalanceSheet`(
		`BalanceSheetID` INTEGER PRIMARY KEY AUTOINCREMENT,
		`BalanceSheetDate` DATE,
		`BalanceSheetDeposits` NUMERIC,
		`BalanceSheetWithdraws` NUMERIC,
		`BalanceSheetAmount` NUMERIC
	);");
$balancesheet->execute();
?>