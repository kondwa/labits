<?php echo "money in."; ?>
<?php
if(@$_POST){
    $amount=$_POST["amount"];
    $action=$_POST["action"];
    $date=@date("d/m/Y");
    $db = new PDO("sqlite:data.sqlite");
    $sth = $db->prepare(
        "INSERT INTO `Cashflow`(`CashflowDate`,`CashflowDesc`,`CashflowDeposit`)
        VALUES(:cdate,:cdesc,:deposit);"
    );
    $sth->execute(array(":cdate"=>$date,":cdesc"=>$action,":deposit"=>$amount));
}
?>
<form method="post">
    <fieldset>
        <legend>Cash Deposit</legend>
        <label>
            Amount(Kwacha):
            <input type="number" name="amount">
        </label>
        <input type="submit" name="action" value="Deposit">
    </fieldset>
</form>