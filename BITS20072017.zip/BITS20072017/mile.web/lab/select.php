<!doctype html>
<?php
$districts = array(
	"Chitipa",
	"Karonga", 
	"Rumphi",
	"Nkhata Bay",
	"Mzimba",
	"Kasungu",
	"Nkhota Kota",
	"Dowa",
	"Ntchisi",
	"Salima",
	"Lilongwe",
	"Mchinji",
	"Dedza",
	"Ntcheu",
	"Mwanza",
	"Zomba",
	"Blantyre",
	"Mulanje",
	"Thyolo",
	"Mangochi",
	"Machinga",
	"Nsanje"
);
?>
<html>
	<head>
		<title>select button</title>
	</head>
	<body>
		<?php var_export($_POST); ?>
		<form method="post">
			<label for="district">District</label>
			<input list="districts" type="text" name="district">
			<datalist id="districts">
				<?php foreach($districts as $district): ?>
					<option><?php echo $district; ?></option>
				<?php endforeach; ?>	
			</datalist>
			<input type="submit" value="save" />
		</form>
	</body>
</html>