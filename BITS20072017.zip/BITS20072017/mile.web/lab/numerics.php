<?php 
    $z30 = "123456789012345678901234567890";
    $z10 = "1234567890";
    echo "$z30 - $z10 = ";
    //echo $z30 - $z10;
    function subtract($a,$b){
        $sa=str_split($a);
        $sb=str_split($b);
        $rs = array();
        do{
            $na = array_pop($sa);
            $nb = array_pop($sb);
            $rn = $na*1-$nb*1;
           array_unshift($rs,"$rn");
        }while($sa || $sb);
        echo implode($rs);
    }
    subtract($z30,$z10);
    echo "<hr>";
    echo "1000 - 10 = ";
    subtract("1000","10");
?>