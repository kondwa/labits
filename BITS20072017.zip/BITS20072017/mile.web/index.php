<?php include ".inc/oi.php"; ?>
<!DOCTYPE html>
<html>
	<head>
		<title>mile</title>
		<link href=".css/style.css" rel="stylesheet" />
		<meta name="author" content="Oisp(R)" />
	</head>
	<body>
		<div id="main">
			<div id="menu">
				<?php if(secure()): ?>
					<a href="?action=dashboard"><img src=".ico/dashboard.png" /></a>
					<a href="?action=signoff"><img src=".ico/signoff.png" /></a>
				<?php else: ?>
					<a href="."><img src=".ico/home.png" /></a>
					<a href="?action=signon"><img src=".ico/signon.png" /></a>
					<a href="?action=signup"><img src=".ico/signup.png" /></a>
				<?php endif; ?>
			</div>
			<h1>Contacts</h1>
			<div id="content">
				<?php route(); ?>
			</div>
			<h5>&copy;Oisp&reg;</h5>
		</div>
	</body>
</html>