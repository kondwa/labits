<!doctype html public>
<html>
	<head>
		<title>ephod</title>
		<style type="text/css">
			.ephod{
				border: 1px solid #080;
				padding: 1em;
			}
			.stone{
				width: 7em;
				height: 7em;
				border: 1px solid #080;
				margin: 1px;
			}
		</style>
	</head>
	<body>
		<table class="ephod">
			<tr>
				<td class="stone">
					ruby
					<table>
			<caption>month</caption>
			<thead>
				<th>1st</th>
				<th>2nd</th>
				<th>3rd</th>
				<th>4th</th>
				<th>5th</th>
				<th>6th</th>
				<th>7th</th>
			</thead>
			<tr class="week">
				<td class="day">1</td>
				<td class="day">2</td>
				<td class="day">3</td>
				<td class="day">4</td>
				<td class="day">5</td>
				<td class="day">6</td>
				<td class="day">7</td>
			</tr>
			<tr class="week">
				<td class="day">8</td>
				<td class="day">9</td>
				<td class="day">10</td>
				<td class="day">11</td>
				<td class="day">12</td>
				<td class="day">13</td>
				<td class="day">14</td>
			</tr>
			<tr class="week">
				<td class="day">15</td>
				<td class="day">16</td>
				<td class="day">17</td>
				<td class="day">18</td>
				<td class="day">19</td>	
				<td class="day">20</td>
				<td class="day">21</td>
			</tr>
			<tr class="week">
				<td class="day">22</td>
				<td class="day">23</td>
				<td class="day">24</td>
				<td class="day">25</td>
				<td class="day">26</td>		
				<td class="day">27</td>
				<td class="day">28</td>
			</tr>
		</table>
				</td>
				<td class="stone">topaz</td>
				<td class="stone">garnet</td>
			</tr>
			<tr>
				<td class="stone">emerald</td>
				<td class="stone">sapphire</td>
				<td class="stone">diamond</td>
			</tr>
			<tr>
				<td class="stone">turqoise</td>
				<td class="stone">agate</td>
				<td class="stone">amethyst</td>
			</tr>
			<tr>
				<td class="stone">beryl</td>
				<td class="stone">carnelian</td>
				<td class="stone">jasper</td>
			</td>
		<table>
		<table>
			<caption>month</caption>
			<thead>
				<th>1st</th>
				<th>2nd</th>
				<th>3rd</th>
				<th>4th</th>
				<th>5th</th>
				<th>6th</th>
				<th>7th</th>
			</thead>
			<tr class="week">
				<td class="day">1</td>
				<td class="day">2</td>
				<td class="day">3</td>
				<td class="day">4</td>
				<td class="day">5</td>
				<td class="day">6</td>
				<td class="day">7</td>
			</tr>
			<tr class="week">
				<td class="day">8</td>
				<td class="day">9</td>
				<td class="day">10</td>
				<td class="day">11</td>
				<td class="day">12</td>
				<td class="day">13</td>
				<td class="day">14</td>
			</tr>
			<tr class="week">
				<td class="day">15</td>
				<td class="day">16</td>
				<td class="day">17</td>
				<td class="day">18</td>
				<td class="day">19</td>	
				<td class="day">20</td>
				<td class="day">21</td>
			</tr>
			<tr class="week">
				<td class="day">22</td>
				<td class="day">23</td>
				<td class="day">24</td>
				<td class="day">25</td>
				<td class="day">26</td>		
				<td class="day">27</td>
				<td class="day">28</td>
			</tr>
		</table>
	</body>
</html>