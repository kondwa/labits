<?php echo "php lab."; ?>
<?php
	$db = new PDO("sqlite:data.sqlite");
	$cashflow = $db->prepare(
		"CREATE TABLE IF NOT EXISTS `Cashflow`(
			`CashflowID` INTEGER AUTOINCREMENT,
			`CashflowDate` DATE,
			`CashflowDesc` TEXT,
			`CashflowDeposit` NUMERIC,
			`CashflowWithdraw` NUMERIC,
			PRIMARY KEY(`CashflowID`)
	);");
	$cashflow->execute();
	$balancesheet = $db->prepare(
		"CREATE TABLE IF NOT EXISTS `BalanceSheet`(
            `BalanceSheetID` INTEGER PRIMARY KEY AUTOINCREMENT,
            `BalanceSheetDate` DATE,
            `BalanceSheetDeposits` NUMERIC,
            `BalanceSheetWithdraws` NUMERIC,
            `BalanceSheetAmount` NUMERIC
		);");
	$balancesheet->execute();
	$deposit = $db->prepare("
		INSERT INTO `Cashflow`(`CashflowDate`,`CashflowDesc`,`CashflowDeposit`)
		VALUES(:cashflowdate,:cashflowdesc,:cashflowdeposit);
	");
	$deposit->execute([":cashflowdate"=>@date(DATE_ATOM),":cashflowdesc"=>"cash deposit.",":cashflowdeposit"=>500.00]);
	/*
	$cashflowstatement=$db->prepare("SELECT * FROM `Cashflow`;");
	$cashflowstatement->execute();
	$result = $cashflowstatement->fetchObject();
	var_export($result);
    */
?>