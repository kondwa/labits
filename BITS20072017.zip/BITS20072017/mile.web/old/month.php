<!doctype html>
<script type="text/javascript">

	var o=document.getElementById("o");
	for(var h=0; h < 24; h++){
		for(var m=0; m < 60; m++){
			for(var s = 0; s < 60 ; s++){
				window.console(h+":"+m+":"+s);	
			}
		}
	}
</script>