<!doctype html public>
<?php include "oi.php"; ?>
<html>
	<head>
		<title><?php echo "oi.ws"; ?></title>
	</head>
	<body>
		<?php echo "Oops! under construction."; ?>
	</body>
</html>