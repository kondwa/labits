<!doctype html>
<html>
	<head>
		<title>NanOS™</title>
		<link href=".css/oi.css" rel="stylesheet" />
	</head>
	<body>
		<div class="top">NanOS&trade;</div>
		<!--div class="menu"><a href="?a=card">&</a></div-->
		<div class="box">
			<h3>Footsteps</h3>
			<p>A journey of a thousand miles begins with one step.</p>
		</div>
		<div class="box">
			<h3>Wisdom</h3>
			<p>Don't be wise in you own eyes; fear God and shun evil.</p>
		</div>
		<div class="box">
			<h3>Shades of Gray</h3>
			<p>Remember God in the days of your youth.</p>
		</div>
	</body>
</html>