<!doctype html>
<html>
    <head>
        <title>NanOS™ Diary</title>
        <link href=".css/diary.css" rel="stylesheet" />
    </head>
    <body>
        <div id="main">
            <h1>NanOS™ Diary</h1>
            <div class="box">
                <h3><?php echo date("jS F, Y"); ?></h3>
                <form method="post">
                    <textarea></textarea>
                    <input type="submit" value="Save">
                </form>
            </div>
        </div>
    </body>
</html>