<!doctype html>
<html>
	<head>
		<title>Banka O Franca</title>
		<link href=".css/bank.css" rel="stylesheet" />
	</head>
	<body>
		<div id="main">
			<h1 class="top">Banka O Franca</h1>
			<i>the truth of a bank</i>
			<div id="menu">
				<div class="box">
					<h3><img src=".ico/money.png" /><img src=".ico/coins-in.png" /><br />deposits</h3>
					<p>money in.</p>
					<h5 align="right"><a href="?do=deposits"><img src=".ico/money.png" /><img src=".ico/coins-in.png" /></a></h5>
				</div>
				<div class="box">
					<h3><img src=".ico/money.png" /><img src=".ico/coins-out.png" /><br />withdraws</h3>
					<p>money out.</p>
					<h5 align="right"><a href="?do=withdraws"><img src=".ico/money.png" /><img src=".ico/coins-out.png" /></a></h5>
				</div>
				<div class="box">
					<h3><img src=".ico/money.png" /><img src=".ico/coins.png" /><br />enquiries</h3>
					<p>the bank's truth.</p>
					<h5 align="right"><a href="?do=enquiries"><img src=".ico/money.png" /><img src=".ico/coins.png" /></a></h5>
				</div>
				<div class="widebox">
					<h3><img src=".ico/vcard.png" /><br />account</h3>
					<p>
					<form method="post">
						<label><input type=text name="account" placeholder="bank account..." /></label>
						<input type="image" src=".ico/find.png" value="find" />
					</form>
					</p>
					<p>
						<?php //var_export($_POST); ?>
					</p>
				</div>
			</div>
		</div>
	</body>
</html>