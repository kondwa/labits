<?php
trait Name {
	public first;
	public last;
	public middle;
	private uid
}

?>