<?php
if($_POST):
	signin();
else:
?>
<form method="post">
	<fieldset>
		<legend>Sign in</legend>
		<label>
			Email
			<input type="email" name="email" required="true" placeholder="email" />
		</label>
		<label>
			Password
			<input type="password" name="password" required="true" placeholder="password" />
		</label>
		<div align="right">
			<input type="submit" value="Sign in" />
		</div>
	</fieldset>
</form>
<?php endif; ?>