<?php
 if($_POST):
	 if(signup()){ echo "signed up successfully."; };
 else:
?>
<form method="post">
	<fieldset>
		<legend>Sign up</legend>
		<label>
			User Account
			<input type="email" name="ua[email]" placeholder="email" required="true" />
			<input type="password" name="ua[password]" placeholder="password" required="true" />
		</label>
		<label>
			Name
			<input type="text" name="name[first]" placeholder="first name" required="true" />
			<input type="text" name="name[last]" placeholder="last name" required="true" />
		</label>
		<div align="right">
			<input type="submit" value="Sign up" />
		</div>
	</fieldset>
</form>
<?php endif; ?>