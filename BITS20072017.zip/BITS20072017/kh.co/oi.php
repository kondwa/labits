<?php
	include ".inc/e.php";
	include ".inc/db.php";
	include ".inc/s.php";
?>