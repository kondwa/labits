<!doctype html public>
<?php include "oi.php"; ?> 
<html>
	<head>
		<title><?php echo "(KH)"; ?></title>
		<link href=".css/layout.css" rel="stylesheet" />
		<link href=".css/form.css" rel="stylesheet" />
	</head>
	<body>
		<div id="main">
			<div id="menu">
				<?php if(secure()): ?>
				<a href="?m=ua/so">Sign out</a>
				<?php else: ?>
				<a href="?m=ua/su">Sign up</a>
				<a href="?m=ua/si">Sign in</a>
				<?php endif; ?>
			</div>
			<h1>App</h1>
			<div>
			<?php
				if($_GET){	
					$m = $_GET['m'];
					include "$m.php";
				}
			?>
			</div>
			<h5>(kh)</h5>
		</div>
	</body>
</html>