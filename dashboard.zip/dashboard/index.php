<!doctype html public>
<html>
    <head>
        <title>Dashboard</title>
        <link href="css/main.css" rel="stylesheet">
    </head>
    <body>
        <div id="main">
            <div id="nav">
                <a href="?action=Deposit">Cash Deposit</a> | 
                <a href="?action=Withdraw">Cash Withdraw</a> |
                <a href="?action=Balance">Account Balance</a>
            </div>
            <h1>Dashboard</h1>
            <div>
            <?php
                @$action = $_REQUEST["action"];
                switch($action){
                    case 'Deposit': 
                        include "in.php";
                    break;
                    case 'Withdraw':
                        include "out.php";
                    break;
                    case "Balance":
                        include "cashflow.php";
                    break;
                    default:
                        echo "Hi, how are you?";
                }
            ?>
            </div>
            <h5 align="right"> &copy; Oisp &reg;</h5>
        </div>
    </body>
</html>