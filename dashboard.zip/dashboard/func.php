<?php
function initdb(){
	$db = new PDO("sqlite:nano.data");
	$db->query(
		"CREATE TABLE IF NOT EXISTS cashflow(
			tid INTEGER PRIMARY KEY AUTOINCREMENT,
			tdate DATE,
			description TEXT,
			deposit NUMERIC,
			withdraw NUMERIC
		);"
	);
	$db->query(
		"CREATE TABLE IF NOT EXISTS `balancesheet`(
			tid INTEGER PRIMARY KEY AUTOINCREMENT,
			tdate DATE,
			deposits NUMERIC,
			withdraws NUMERIC,
			balance NUMERIC
		);"
	);
}
function deposit($tdate,$descrition,$amount){
	$db = new PDO("sqlite:nano.data");
	$db->beginTransaction();
	$db->exec(
		"INSERT INTO cashflow(tdate,description,deposit)
		VALUES($tdate,$descrition,$amount);"
	);
	$db->commit();
}
function withdraw($tdate,$descrition,$amount){
	$db = new PDO("sqlite:nano.data");
	$db->query(
		"INSERT INTO cashflow(tdate,description,withdraw)
		VALUES($tdate,$descrition,$amount);"
	);
}
function balance(){
	$db = new PDO("sqlite:nano.data");
	$db->beginTransaction();		
	$res = $db->query(
		"SELECT SUM(deposit) AS deposits, SUM(withdraw) AS withdraws FROM cashflow;"
	);
	$data = $res->fetchObject();
	$db->commit();
	return ($data->deposits - $data->withdraws);
}
?>
<dl>
	<dt>initialise database</dt>
	<dd><?php 
		try{ 
			initdb(); 
			echo "database ok."; 
		}catch(Exception $e){ 
			echo $e->getMessage(); 
		} ?>
	</dd>
	<dt>make transactions</dt>
	<dd><?php 
		try{ 
			deposit("01/29/2017","Cash Deposit",500); 
			echo "Deposit: K500"; 
		}catch(Exception $e){
			echo $e->getMessage();
		}
	?>
	</dd>
	<dd>
	<?php
		try{
			withdraw("01/29/2017","Cash withdraw",50);
			echo "Withdraw: K50.";
		}catch(Exception $e){
			echo $e->getMessage();
		}
	?>
	</dd>
	<dd>
		<?php
			try{
				echo "Balance: ". balance();
			}catch(Exception $e){
				$e->getMessage();
			}
		?>
	</dd>
</dl>