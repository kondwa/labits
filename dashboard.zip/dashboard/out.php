<?php if(@$_POST[action]): ?>
<?php 
$amount = $_POST['amount'];
$date = $_POST['date'];
$description = $_POST['description'];
try{
    $db = new PDO("sqlite:nano.data");
    $db->query("
        INSERT INTO cashflow(tdate,description,withdraw)
        VALUES('$date','$description',$amount);
    ");
    echo "Cash Withdraw done.";
}catch(Exception $e){
    echo $e->getMessage();
}
?>
<?php else: ?>
<form name="out" method="post">
    <fieldset>
        <legend>Cash Withdraw</legend>
        <label>
            Date
            <input type="date" name="date">
        </label>
            <input type="hidden" name="description" value="Cash Withdraw">
        <label>
            Amount(K)
            <input type="number" name="amount">
        </label>
        <input type="submit" name="action" value="Withdraw">
    </fieldset>
</form>
<?php endif; ?>