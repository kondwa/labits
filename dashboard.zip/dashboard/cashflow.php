<?php
try{
	$db = new PDO("sqlite:nano.data");
	$cashflow = $db->query("SELECT * FROM cashflow;");
	$result = $db->query(
		"SELECT 
			SUM(deposit) AS deposits, 
			SUM(withdraw) AS withdraws 
		FROM cashflow;"
	);
	$res = $result->fetch();
}catch(Exception $e){
	$e->getMessage();
}
?>
<div>
	<?php 
		$balance = $res['deposits']-$res['withdraws'];
	?>
	<dl>
		<dt>Cashflow Statement</dt>
		<dd>
			<table>
				<thead align="left">
					<th>Date</td>
					<th>Description</th>
					<th>Deposit(K)</th>
					<th>Withdraw(K)</th>
				<thead>
			<tbody>
			<?php foreach($cashflow as $transaction): ?>
				<tr>
					<td align="center"><?php echo $transaction['tdate']; ?></td>
					<td aligh="left" width="200"><?php echo $transaction['description']; ?></td>
					<td align="right" class="in" width="100"><?php echo number_format($transaction['deposit'],2); ?></td>
					<td align="right" class="out" width="100"><?php echo number_format($transaction['withdraw'],2); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
			<tfoot>
				<th align="center">&nbsp;</th>
				<th aligh="left">&nbsp;</td>
				<th align="right">K <?php echo number_format($res['deposits'],2); ?></th>
				<th align="right">K <?php echo number_format($res['withdraws'],2); ?></th>
			</tfoot>
		</table>
		</dd>
	</dl>
</div>