<ol>
<?php
    echo "<li>preparing database.</li>";
    try{
        $db = new PDO("sqlite:nano.data");
        echo "<li> database ready.</li>";
    }catch(Exception $e){
        echo "<li>" . $e->getMessage() . "</li>";
    }
    echo "<li> creating 'cashflow' table.</li>";
    try{
        $db->query(
            "CREATE TABLE cashflow(
                tid INTEGER PRIMARY KEY AUTOINCREMENT,
                tdate DATE,
                description TEXT,
                deposit NUMERIC,
                withdraw NUMERIC
            );"
        );
        echo "<li> 'cashflow' table is created. </li>";
    }catch(Exception $e){
        echo "<li>" . $e->getMessage() . "</li>";
    }
    echo "<li> creating 'balancesheet' table. </li>";
    try{
        $db->query(
            "CREATE TABLE `balancesheet`(
                `tid` INTEGER PRIMARY KEY AUTOINCREMENT,
                `tdate` DATE,
                `deposits` NUMERIC,
                `withdraws` NUMERIC,
                `balance` NUMERIC
            );"
        );
        echo "<li> 'balancesheet' table is created. </li>";
    }catch(Exception $e){
        echo "<li>" . $e->getMessage() . "</li>";
    }
    echo "<li> inserting data: a deposit of K500. </li>";
    try{
        $db->query(
            "INSERT INTO cashflow(tdate,description,deposit)
            VALUES('01/29/2017','Cash Deposit',500);"
        );
        echo "<li> made a cash deposit of K500. </li>";
    }catch(Exception $e){
        echo "<li>" . $e->getMessage() . "</li>";
    }
    echo "<li> inserting data: a withdraw of K50. </li>";
    try{
        $db->query(
            "INSERT INTO cashflow(tdate,description,withdraw)
            VALUES('01/29/2017','Cash Withdraw',50);"
        );
        echo "<li> made a cash withdraw of K50. </li>";
    }catch(Exception $e){
        echo "<li>" . $e->getMessage() . "</li>";
    }
    echo "<li> retrieve data: Balance inquery </li>";
    try{
        $res = $db->query(
            "SELECT SUM(deposit) AS deposits, SUM(withdraw) AS withdraws FROM cashflow;"
        );
        $data = $res->fetchAll();
        echo "<li> the balance is: K". ($data[0]['deposits'] - $data[0]['withdraws']);
    }catch(Exception $e){
        echo "<li>" . $e->getMessage(). "</li>";
    }
?>
</ol>