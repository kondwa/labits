<?php if(@$_POST[action]): ?>
<?php 
$amount = $_POST['amount'];
$date = $_POST['date'];
$description = $_POST['description'];
try{
    $db = new PDO("sqlite:nano.data");
    $db->query("
        INSERT INTO cashflow(tdate,description,deposit)
        VALUES('$date','$description',$amount);
    ");
    echo "Cash Deposit done.";
}catch(Exception $e){
    echo $e->getMessage();
}
?>
<?php else: ?>
<form name="in" method="post">
    <fieldset>
        <legend>Cash Deposit</legend>
        <label>
            Date
            <input type="date" name="date">
        </label>
            <input type="hidden" name="description" value="Cash Deposit">
        <label>
            Amount(K)
            <input type="number" name="amount">
        </label>
        <input type="submit" name="action" value="Deposit">
    </fieldset>
</form>
<?php endif; ?>