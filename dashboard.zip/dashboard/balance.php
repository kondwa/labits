<?php
try{
	$db = new PDO("sqlite:nano.data");
	$result = $db->query(
		"SELECT 
			SUM(deposit) AS deposits, 
			SUM(withdraw) AS withdraws 
		FROM cashflow;"
	);
	$res = $result->fetch();
}catch(Exception $e){
	$e->getMessage();
}
?>
<div>
	<?php 
		$balance = $res['deposits']-$res['withdraws'];
	?>
	<dl>
		<dt>Balance Sheet</dt>
		<dd><?php echo "Total Deposits: K " . number_format($res['deposits'],2); ?></dd>
		<dd><?php echo "Total Withdraws: K " . number_format($res['withdraws'],2); ?></dd>
		<dd><hr></dd>
		<dd><?php echo "Balance: K " . number_format($balance,2); ?></dd>
	</dl>
</div>