<?php include "oi/oi.php"; ?>
<?php
if($_POST){
  try{
    $ua->signout();
  }catch(Exception $e){
    echo "Oops. " . $e->getMessage();
  }
}
?>
<form method="post">
  <fieldset>
    <legend>sign out</legend>
    <button type="submit" name="ua">sign out</button>
  </fieldset>
</form>
