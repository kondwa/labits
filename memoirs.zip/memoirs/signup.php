<?php include "oi/oi.php"; ?>
<?php
if($_POST){
  try{
    $ua->signup($_POST);
  }catch(Exception $e){
    echo "Oops. " . $e->getMessage();
  }
}
?>
<form method="post">
  <fieldset>
    <legend>sign up</legend>
    <input type="text" name="firstname" placeholder="first name.." />
    <input type="text" name="lastname" placeholder="last name.." />
    <input type="email" name="email" placeholder="email.." />
    <input type="password" name="password" placeholder="secret.." />
    <button type="submit" name="ua">sign up</button>
  </fieldset>
</form>
