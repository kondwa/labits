<?php include "oi/oi.php"; ?>
<style>
#main{
   width: 5in;
   margin: 5px auto;
   padding: 5px;
   border: 1px solid silver;
   color: darkblue;
}
#main a{
  padding: 5px;
  text-decoration: none;
}
#main h3{
  border-bottom: 1px solid gold;
  margin: 3px;
  padding: 3px;
  color: darkblue;
}
#main h5{
  border-top: 1px solid brown;
  margin: 3px;
  padding: 3px;
  font-size: 10px;
  color: brown;
}
#main p{
  margin: 3px;
  padding: 5px;
}
#menu{
  margin: 2px;
  padding: 2px;
}
#menu a{
  float: right;
  margin:2px;
  padding:2px;
  font-size: small;
}
#menu a:hover{
  color: gold;
}
form{
  display:inline-block;
}
fieldset{
  display: block;
  border: 1px solid silver;
  margin: 3px;
  padding: 5px; 
}
fieldset legend{
  border:1px solid silver;
  margin: 3px;
  padding: 5px;
  color: darkblue;
}
fieldset input, fieldset textarea{
  display: block;
  border: 1px solid silver;
  margin: 3px;
  padding: 7px;
  color: darkblue;
}
fieldset button{
  color: darkblue;
  padding: 7px;
  width: 100%;
}
</style>
<div id="main">
<div id="menu" align="right">
  <?php if($ua->in()): ?>
  <a href=".">[ @ ]</a>
  <a href="?ua=signout">[ o ]</a>
  <?php else: ?>
  <a href="?ua=signup">[ + ]</a>
  <a href="?ua=signin">[ i ]</a>
  <?php endif; ?>
</div>
<h3>oi:memoirs.</h3>
<?php 
# must remember to make it into class::view(data)
$a=@$_GET['ua'];
switch($a){
  case "signup": include "signup.php"; break;
  case "signin": include "signin.php"; break;
  case "signout": include "signout.php"; break;
  default: include "app.php";
}
?>
<h5 align="right"><?php  echo "-KH-"; ?></h5>
</div>
