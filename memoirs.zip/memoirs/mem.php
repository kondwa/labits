<?php
class mem{
  static function post(){
    global $sd, $db; 
    $m=$_POST["memoire"];
    $u=$sd->ua["id"];
    $s=$db->prepare("INSERT INTO memoirs(memoire,date,uid)VALUES(?,NOW(),?)");
    $s->execute(array($m,$u));
  }
  static function get(){
    global $sd, $db;
    $u=$sd->ua["id"];
    $s=$db->prepare("SELECT * FROM memoirs WHERE uid=? ORDER BY date DESC LIMIT 5");
    $s->execute(array($u));
    $ms=array();
    while($r=$s->fetch()){ $ms[]=$r; }
    return $ms;
  }
}
?>
