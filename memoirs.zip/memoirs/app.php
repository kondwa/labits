<style>
.memoirs{
  display:block;
}
.memoirs textarea, .memoirs input{
  width:100%;
}
</style>
<?php if($ua->in()): ?>
<?php
include "mem.php";
if($_POST){
  mem::post();
  /*
  $memoire=$_POST["memoire"];
  $u = $sd->ua;
  $s=$db->prepare("INSERT INTO memoirs(memoire,date,uid)VALUES(?,NOW(),?)");
  $s->execute(array($memoire,$u["id"]));
  */
}
/*
  $u=$sd->ua["id"];
  $s=$db->prepare("SELECT * FROM memoirs WHERE uid=? ORDER BY date DESC");
  $rs=$s->execute(array($u));
  $ms=array();
  while($r = $s->fetch()){ $ms[]=$r; }
*/  
$memoirs = mem::get();

?>
<form method="post" class="memoirs">
  <fieldset>
    <legend>memoire</legend>
    <textarea name="memoire"></textarea>
    <input type="submit" value="post">
  </fieldset>
</form>
<div class="memoirs">
<?php foreach(@$memoirs as $memoire): ?>
 <fieldset>
   <legend><?php echo $memoire["date"]; ?></legend>
   <?php echo $memoire["memoire"]; ?>
 </fieldset>
<?php endforeach; ?>
</div>
<?php else: ?>
<p>public information</p>
<?php endif; ?>
