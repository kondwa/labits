<?php include "oi/oi.php"; ?>
<?php
if($_POST){
  try{
    $ua->signin($_POST);
  }catch(Exception $e){
    echo "Oops. ". $e->getMessage();
  }
}
?>
<form method="post">
  <fieldset>
    <legend>sign in</legend>
    <input type="email" name="email" placeholder="email.." />
    <input type="password" name="password" placeholder="secret.." />
    <button type="submit" name="ua">sign in</button>
  </fieldset>
</form>
