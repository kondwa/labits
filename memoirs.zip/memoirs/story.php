mile&trade; vs mile&reg;
