<?php
print_r($_REQUEST);

?>
<form method="POST">
 <input type=text name=data value=set>
 <input type=submit value="update">
</form>
