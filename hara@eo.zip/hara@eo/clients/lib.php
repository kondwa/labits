<?
	$DB['host']="localhost";
	$DB['name']="clientdb";
	$DB['user']="eo";
	$DB['pass']="pass";
	function dbOpen(){
		global $DB,$dbh;
		$dbh=mysql_connect($DB['host'],$DB['user'],$DB['pass']) or die(mysql_error());
		mysql_select_db($DB['name']);
	}
	function dbClose(){
		global $dbh;
		mysql_close($dbh);
	}
	function nav(){
		$htm='';
		foreach(range("A","Z") as $L){
			$qry="SELECT * FROM client WHERE " . 
				"fname LIKE '$L%'" . " OR " .
				"lname LIKE '$L%'" . " OR " .
				"org LIKE '$L%'" . " OR " .
				"email LIKE '$L%'" . " OR " .
				"uname LIKE '$L%'";
			$fnd=( mysql_fetch_assoc(mysql_query($qry) ) )?true:false;
			$htm .= ($htm)? " " : "" ;
			$htm .= ($fnd)?"<a href='?do=list&s=$L'>$L</a>":"$L";
		}
		print $htm;
	}
	function results(){
		print_r($_POST);
	}
	function fix($data){
		foreach($data as $k=>$v){
			$data[$k]=mysql_escape_string( stripslashes( strip_tags($v) ) );
		}
		return $data;
	}
	function lastid(){
		$res=mysql_fetch_assoc(mysql_query("SELECT max(id) as last FROM client"));
		return $res['last'];
	}
	function update($data){
		if( @extract( fix($data) ) ){
			$qry="UPDATE client SET `cno`='$cno', `fname`='$fname', `lname`='$lname', `org`='$org', `address`='$address', `office`='$office', `home`='$home', `cell`='$cell', `email`='$email', `uname`='$uname', `passwd`='$passwd' WHERE `id`='$id'";
			mysql_query($qry) or die("Error: ".mysql_error());
			print "Data updated!";
		}
	}
	function insert($data){
		if( @extract( fix($data) ) ){
			$qry="INSERT INTO client SET `cno`='$cno', `fname`='$fname', `lname`='$lname', `org`='$org', `address`='$address', `office`='$office', `home`='$home', `cell`='$cell', `email`='$email', `uname`='$uname', `passwd`='$passwd'";
			mysql_query($qry) or die("Error: ".mysql_error());
			print "Data saved!";
		}
	}
	function select($id){
		$id=($id)? $id : lastid();
		$res = mysql_query("SELECT * FROM client WHERE `id`=$id") or die("Error: ".mysql_error());
		return mysql_fetch_assoc($res);
	}
	function showform(){
		global $data;
		@extract($data);
		if($do != "add" )@extract(select($id));
		?>
		<table align="center" class="info">
    	  <tr align="right" class="thead">
        	<td colspan="4" align="left" class="theading">Customer Information
       	    <input name="id" type="hidden" id="id" value="<?=$id;?>" /></td>
	      </tr>
    	  <tr class="trow">
	        <th align="right">Customer ID: </th>
    	    <td><input name="cno" type="text" class="input" id="cno" value="<?=$cno;?>" /></td>
        	<th align="right">&nbsp;</th>
	        <td>&nbsp;</td>
    	  </tr>
	      <tr class="trow">
    	    <th width="110" align="right">First Name:</th>
        	<td width="110"><input name="fname" type="text" class="input" id="fname" value="<?=$fname;?>" /></td>
	        <th width="110" align="right">Last Name:</th>
    	    <td width="110"><input name="lname" type="text" class="input" id="lname" value="<?=$lname;?>" /></td>
	      </tr>
    	  <tr class="trow">
	        <th width="110" align="right">Organization:</th>
    	    <td width="110"><input name="org" type="text" class="input" id="org" value="<?=$org;?>" /></td>
        	<th width="110" align="right">Address:</th>
	        <td width="110" rowspan="2"><textarea name="address" cols="16" rows="2" class="input" id="address"><?=$address;?></textarea></td>
    	  </tr>
	      <tr class="trow">
    	    <th width="110" align="right">&nbsp;</th>
        	<td width="110">&nbsp;</td>
	        <th width="110" align="right">&nbsp;</th>
   	      </tr>
	      <tr align="right">
    	    <td colspan="4" align="left" class="theading">Phones</td>
	      </tr>
    	  <tr class="trow">
        	<th width="110" align="right">Office:</th>
	        <td width="110"><input name="office" type="text" class="input" id="office" value="<?=$office;?>" /></td>
    	    <th width="110" align="right">Home:</th>
        	<td width="110"><input name="home" type="text" class="input" id="home" value="<?=$home;?>" /></td>
	      </tr>
    	  <tr class="trow">
        	<th width="110" align="right">Cell:</th>
	        <td width="110"><input name="cell" type="text" class="input" id="cell" value="<?=$cell;?>" /></td>
    	    <th width="110" align="right">&nbsp;</th>
        	<td width="110">&nbsp;</td>
	      </tr>
    	  <tr align="right">
        	<td colspan="4" align="left" class="theading">Account Information</td>
	      </tr>
    	  <!--tr class="trow">
        	<th align="right">Account Type: </th>
	        <td><select name="select">
    	      <option value="1">email only</option>
        	</select>        </td>
	        <td>&nbsp;</td>
    	    <td>&nbsp;</td>
	      </tr-->
    	  <tr class="trow">
        	<th width="110" align="right">Email Address: </th>
	        <td width="110">
			<input name="email" type="text" class="input" id="email" value="<?=$email;?>" size="6" />
			@eomw.net</td>
        	<th width="110" align="right">&nbsp;</th>
	        <td width="110">&nbsp;</td>
    	  </tr>
	      <tr class="trow">
    	    <th width="110" align="right">Username:</th>
        	<td width="110"><input name="uname" type="text" class="input" id="uname" value="<?=$uname;?>" /></td>
	        <th width="110" align="right">Password:</th>
    	    <td width="110"><input name="passwd" type="text" class="input" id="passwd" value="<?=$passwd;?>" /></td>
	      </tr>
    	  <tr class="trow">
        	<th align="right">&nbsp;</th>
	        <td colspan="2" align="right"><input name="do" type="submit" class="button" id="do" value="<?=($do=='edit')?"update":"save";?>" /></td>
    	    <td>&nbsp;</td>
	      </tr>
    	</table>
		<?
	}
	function viewinfo(){
		global $data;
		@extract($data);
		@extract(select($id));		
		?>
		<table align="center" class="info">
    	  <tr align="right" class="thead">
        	<td colspan="4" align="left" class="theading">Customer Information
       	    <input name="id" type="hidden" id="id" value="<?=$id;?>" /></td>
	      </tr>
    	  <tr class="trow">
	        <th align="right">Customer ID: </th>
    	    <td><?=$cno;?></td>
        	<th align="right">&nbsp;</th>
	        <td>&nbsp;</td>
    	  </tr>
	      <tr class="trow">
    	    <th width="110" align="right">First Name:</th>
        	<td width="110"><?=$fname;?></td>
	        <th width="110" align="right">Last Name:</th>
    	    <td width="110"><?=$lname;?></td>
	      </tr>
    	  <tr class="trow">
	        <th width="110" align="right">Organization:</th>
    	    <td width="110"><?=$org?></td>
        	<th width="110" align="right">Address:</th>
	        <td width="110" rowspan="2"><?=$address;?></td>
    	  </tr>
	      <tr class="trow">
    	    <th width="110" align="right">&nbsp;</th>
        	<td width="110">&nbsp;</td>
	        <th width="110" align="right">&nbsp;</th>
   	      </tr>
	      <tr align="right">
    	    <td colspan="4" align="left" class="theading">Phones</td>
	      </tr>
    	  <tr class="trow">
        	<th width="110" align="right">Office:</th>
	        <td width="110"><?=$office;?></td>
    	    <th width="110" align="right">Home:</th>
        	<td width="110"><?=$home?></td>
	      </tr>
    	  <tr class="trow">
        	<th width="110" align="right">Cell:</th>
	        <td width="110"><?=$cell;?></td>
    	    <th width="110" align="right">&nbsp;</th>
        	<td width="110">&nbsp;</td>
	      </tr>
    	  <tr align="right">
        	<td colspan="4" align="left" class="theading">Account Information</td>
	      </tr>
    	  <!--tr class="trow">
        	<th align="right">Account Type: </th>
	        <td><select name="select">
    	      <option value="1">email only</option>
        	</select>        </td>
	        <td>&nbsp;</td>
    	    <td>&nbsp;</td>
	      </tr-->
    	  <tr class="trow">
        	<th width="110" align="right">Email Address: </th>
	        <td width="110">
			<?=$email?>@eomw.net</td>
        	<th width="110" align="right">&nbsp;</th>
	        <td width="110">&nbsp;</td>
    	  </tr>
	      <tr class="trow">
    	    <th width="110" align="right">Username:</th>
        	<td width="110"><?=$uname;?></td>
	        <th width="110" align="right">Password:</th>
    	    <td width="110"><?=$passwd;?></td>
	      </tr>
    	  <tr class="trow">
    	    <th colspan="4" align="right">&nbsp;</th>
   	      </tr>
    	  <tr class="trow">
        	<th align="right">&nbsp;</th>
	        <td align="left"><?=$prev;?></td>
	        <td align="right"><?=$next;?></td>
	        <td>&nbsp;</td>
	      </tr>
    	</table>
		<?
	}
	function search($s,$ls=false){
		$infix = ($ls)?"start with letter":"match";
		$s=array_shift(fix(array($s)));
		if($ls){
			$qry="SELECT * FROM client WHERE " . 
				"fname LIKE '$s%'" . " OR " .
				"lname LIKE '$s%'" . " OR " .
				"org LIKE '$s%'" . " OR " .
				"email LIKE '$s%'" . " OR " .
				"uname LIKE '$s%'";
		}else{
			$qry="SELECT * FROM client WHERE MATCH(cno,fname,lname,org,email,uname) AGAINST('$s*' IN BOOLEAN MODE)";
		}
		$res=mysql_query($qry);
		if(!mysql_num_rows($res)){
			print "Sorry, no client whose details $infix <em>$s</em> was found";
		}else{
			print "Clients whose details $infix <em>$s</em>";
			?>
			<table width="75%">
				<tr class="theading">
					<td width="90">Customer # </td>
			  		<td>Name</td>
					<td>Organisation</td>
					<td colspan="2">Action</td>
			  </tr>
			<?
			while($row=mysql_fetch_assoc($res)){
				?>
				<tr class="trow">
					<td width="90"><?=$row['cno'];?></td>
					<td><?=trim("$row[fname] $row[lname]");?></td>
					<td><?=$row['org'];?></td>
					<td width="25" align="center"><a href="user.php?id=<?=$row['id'];?>">info</a></td>					
					<td width="25" align="center"><a href="user.php?do=edit&id=<?=$row['id'];?>">edit</a></td>
				</tr>
				<?
			}
			?>
</table>
		<?		
		}
	}
?>
