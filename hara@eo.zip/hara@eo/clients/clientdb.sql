CREATE DATABASE clientdb;
GRANT ALL ON clientdb.* to 'eo'@'localhost' IDENTIFIED BY 'pass';
USE clientdb;

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `id` int(11) NOT NULL auto_increment,
  `cno` char(10) default '',
  `fname` char(50) default '',
  `lname` char(50) default '',
  `org` char(100) default '',
  `address` blob default '',
  `office` char(50) default '',
  `home` char(50) default '',
  `cell` char(50) default '',
  `email` char(100) default '',
  `uname` char(50) default '',
  `passwd` char(50) default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `cno` (`cno`)
) ENGINE=MyISAM;