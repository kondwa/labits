<? 
require_once('lib.php'); dbOpen();
if($_GET){ @extract($data=$_GET); }
if($_POST){ @extract($data=$_POST); }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Clients DB</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h2 align="center">E&amp;O Clients Database </h2>
<table width="80%" align="center">
  <tr align="center">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr align="center">
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td width="200" align="center">
	<form method="post">
      <input name="s" type="text" class="input" id="s" size="20" />
      <input type="submit" name="do" class="button" value="search" />
    </form>    </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" align="center"><a href="user.php?do=add">new</a> <?=nav();?></td>
  </tr>
  <tr>
    <td colspan="3" align="center">
	<? 
		
		switch($do){
			case "search":
			search($s);
			break;
			case "list":
			search($s,true);
			break;
		}
	?>
	</td>
  </tr>
</table>
<p align="center">&nbsp;</p>
</body>
</html>
<? dbClose(); ?>