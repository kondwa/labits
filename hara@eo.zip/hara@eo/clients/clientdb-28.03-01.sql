-- MySQL dump 9.11
--
-- Host: localhost    Database: clientdb
-- ------------------------------------------------------
-- Server version	4.0.26-nt-log

--
-- Table structure for table `client`
--
DROP TABLE IF EXISTS `client`;
CREATE TABLE client (
  id int(11) NOT NULL auto_increment,
  cno varchar(10) default '',
  fname varchar(50) default '',
  lname varchar(50) default '',
  org varchar(100) default '',
  address blob,
  office varchar(50) default '',
  home varchar(50) default '',
  cell varchar(50) default '',
  email varchar(100) default '',
  uname varchar(50) default '',
  passwd varchar(50) default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `client`
--

INSERT INTO client VALUES (1,'1008','Victoria','Keelan','Norsk Hydro','P.O. Box 31301, LL 3','01.710.480','01.782.684','08.230.056','victoriakeelan','vkeelan','victoria');
INSERT INTO client VALUES (2,'1061','Tama','','Tobacco Association of Malawi','Box 31360, LL 3','01.773.099','','','tama','tama','tamatob');
INSERT INTO client VALUES (3,'1095','Muscco','GM','Muscco','','01 756 000','','','musccogm','muscco','sacco');
INSERT INTO client VALUES (4,'1109','Coda','','Coda and Partners','P.O. Box 30290, LL 3','01 771 078/025','','','coda-malawi','coda','codamw');
INSERT INTO client VALUES (5,'1150','Felix M.L.','Salaniponi','TB Control Programme','P/Bag 65, LL 3','01.742.035','01.722.063','08.823.006','felix','felix','fiona');
INSERT INTO client VALUES (6,'1171','Michael & Claris','O\'Carroll','','Box 30102, LL 3','','01.794.018','','nicla','mila','clam');
INSERT INTO client VALUES (7,'1216','Pearson','Kachali','Promat Limited','Box 30041, LL 3','01.710.388','01.756.357','','promat','promat','pk2000');
INSERT INTO client VALUES (8,'1234','Joseph','Chimangafisi','Chimangafisi and Partners','Box 30552, LL 3','01.784.756/781.020','01.730.038','','jscap','jscap','');
INSERT INTO client VALUES (9,'1279','Julio','Feliu','Missionaries of Africa','Box 155, LL 3\r\nLikuni Parish','01.752.314','01.766.049','09.918.976','julio','feliu','fjfo');
INSERT INTO client VALUES (10,'1283','George','Willow','Anglican Diocese of Lake Malawi','Area 18A, Opp. Police HQ.','01.797.558','01.796.463','08.301.679','anglama','adlm','malawi');

