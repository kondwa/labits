-- MySQL dump 10.9
--
-- Host: localhost    Database: clientdb
-- ------------------------------------------------------
-- Server version	4.1.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client2`;
CREATE TABLE `client2` (
  `id` int(11) NOT NULL auto_increment,
  `cno` varchar(10) default '',
  `fname` varchar(50) default '',
  `lname` varchar(50) default '',
  `org` varchar(100) default '',
  `address` blob,
  `office` varchar(50) default '',
  `home` varchar(50) default '',
  `cell` varchar(50) default '',
  `email` varchar(100) default '',
  `uname` varchar(50) default '',
  `passwd` varchar(50) default '',
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `cno` (`cno`,`fname`,`lname`,`org`,`uname`,`email`)
) ENGINE=MyISAM;

--
-- Dumping data for table `client`
--


/*!40000 ALTER TABLE `client` DISABLE KEYS */;
LOCK TABLES `client` WRITE;
INSERT INTO `client` VALUES (1,'1008','Victoria','Keelan','Norsk Hydro','P.O. Box 31301, LL 3','01.710.480','01.782.684','08.230.056','victoriakeelan','vkeelan','victoria'),(2,'1061','Tama','','Tobacco Association of Malawi','Box 31360, LL 3','01.773.099','','','tama','tama','tamatob'),(3,'1095','Muscco','GM','Muscco','','01 756 000','','','musccogm','muscco','sacco'),(4,'1109','Coda','','Coda and Partners','P.O. Box 30290, LL 3','01 771 078/025','','','coda-malawi','coda','codamw'),(5,'1150','Felix M.L.','Salaniponi','TB Control Programme','P/Bag 65, LL 3','01.742.035','01.722.063','08.823.006','felix','felix','fiona'),(6,'1171','Michael & Claris','O\'Carroll','','Box 30102, LL 3','','01.794.018','','nicla','mila','clam'),(7,'1216','Pearson','Kachali','Promat Limited','Box 30041, LL 3','01.710.388','01.756.357','','promat','promat','pk2000'),(8,'1234','Joseph','Chimangafisi','Chimangafisi and Partners','Box 30552, LL 3','01.784.756/781.020','01.730.038','','jscap','jscap',''),(9,'1279','Julio','Feliu','Missionaries of Africa','Box 155, LL 3\r\nLikuni Parish','01.752.314','01.766.049','09.918.976','julio','feliu','fjfo'),(10,'1283','George','Willow','Anglican Diocese of Lake Malawi','Area 18A, Opp. Police HQ.','01.797.558','01.796.463','08.301.679','anglama','adlm','malawi'),(11,'1008','Victoria','Keelan','Yara Malawi','Kanengo','01.710.480','','','Victoria Keelan','Vkleen','Victoria'),(12,'1061','Chilabade','','Tobacco Association of Malawi','City Centre','01.773099','','','Tama','tama','tamatob'),(13,'1109','','','Coda and Partners','Development house City Centre','01.771.025','','','Coda malawi','Coda','Coda Malawi'),(14,'1145','Secretary General','','Malawi Red Cross','Off Presidential Way Area 14','01.775.520','','','MRCS','redcross','Society'),(15,'1150','Dr.Fellix','Salaniponi','TB Control Programme','Area 3','01.756.856','','','Felix','felix','Fiona'),(16,'1171','Claris and Michael','OCarroll','OCarroll Personal','Area 43','01.794.018','','09.917.082','nicla','mila','clam'),(17,'1216','Pearson','Kachali','Promat Limited','Kanengo','01.710.388','','','Promat','promat','Pk2000'),(18,'1400','Mussa','Patel','E.P.I Limited','Old Town Chilambula road','01.750.115','','','epi','musa','pattel');
UNLOCK TABLES;
/*!40000 ALTER TABLE `client` ENABLE KEYS */;

--
-- Table structure for table `client2`
--

DROP TABLE IF EXISTS `client2`;
CREATE TABLE `client2` (
  `id` int(11) NOT NULL default '0',
  `cno` varchar(10) default '',
  `fname` varchar(50) default '',
  `lname` varchar(50) default '',
  `org` varchar(100) default '',
  `address` blob,
  `office` varchar(50) default '',
  `home` varchar(50) default '',
  `cell` varchar(50) default '',
  `email` varchar(100) default '',
  `uname` varchar(50) default '',
  `passwd` varchar(50) default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client2`
--


/*!40000 ALTER TABLE `client2` DISABLE KEYS */;
LOCK TABLES `client2` WRITE;
INSERT INTO `client2` VALUES (11,'1008','Victoria','Keelan','Yara Malawi','Kanengo','01.710.480','','','Victoria Keelan','Vkleen','Victoria'),(12,'1061','Chilabade','','Tobacco Association of Malawi','City Centre','01.773099','','','Tama','tama','tamatob'),(13,'1109','','','Coda and Partners','Development house City Centre','01.771.025','','','Coda malawi','Coda','Coda Malawi'),(14,'1145','Secretary General','','Malawi Red Cross','Off Presidential Way Area 14','01.775.520','','','MRCS','redcross','Society'),(15,'1150','Dr.Fellix','Salaniponi','TB Control Programme','Area 3','01.756.856','','','Felix','felix','Fiona'),(16,'1171','Claris and Michael','OCarroll','OCarroll Personal','Area 43','01.794.018','','09.917.082','nicla','mila','clam'),(17,'1216','Pearson','Kachali','Promat Limited','Kanengo','01.710.388','','','Promat','promat','Pk2000');
UNLOCK TABLES;
/*!40000 ALTER TABLE `client2` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

