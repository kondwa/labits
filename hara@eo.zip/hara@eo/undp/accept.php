<?

include_once("config.php");
database_connect();

/** 
* this is ONLY ever called with ?id=cid 
* we make use of the 'menuid' column of undp.content
* we need to change _both_ the menus, as well as the content
* the latter by deleting the appropriate htm(l) file in /cache
*/
    	$cid = $_GET['id'];
	$qry="UPDATE content SET changed=0 WHERE id=$cid";
	if(!mysql_query($qry)){ print mysql_error(); exit; }
	
	$qry="SELECT menuid,cso FROM content WHERE id=$cid";
	if(!$res = mysql_query($qry)){ print mysql_error(); exit; }

	$row = mysql_fetch_assoc($res);
	$id = $row['menuid'];
	$cso=$row['cso'];
	if($id!=-2){
		$qry="UPDATE menus SET changed=0 WHERE id=$id";
	}else{
		$qry="UPDATE menus SET changed=0 WHERE name='$cso'";
	}
	if(!mysql_query($qry)){ print mysql_error(); exit; }

	// then remove the cached file
	$cacheDir  = dirname(__FILE__) . '/cache/';
	$cacheFile = $cacheDir . '_' . $cid. '.htm';	// for cid's
	@unlink($cacheFile);
		
	// finaly, get us back!
    	header("Location: index.php?ok=$cid");
?>
