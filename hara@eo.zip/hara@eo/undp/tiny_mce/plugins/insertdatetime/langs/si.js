// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
insertdate_def_fmt : '%d.%m.%Y',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Vstavi datum',
inserttime_desc : 'Vstavi uro',
inserttime_months_long : new Array("Januar", "Februar", "Marec", "April", "Maj", "Junij", "Julij", "August", "September", "Oktober", "November", "December"),
inserttime_months_short : new Array("Jan", "Feb", "Mar", "Apr", "Maj", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"),
inserttime_day_long : new Array("Nedelja", "Ponedeljek", "Torek", "Sreda", "&#268;etrtek", "Petek", "Sobota", "Nedelja"),
inserttime_day_short : new Array("Ned", "Pon", "Tor", "Sre", "&#268;et", "Pet", "Sob", "Ned")
});
