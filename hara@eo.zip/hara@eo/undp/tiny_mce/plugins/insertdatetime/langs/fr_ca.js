// Canadian French lang variables by Virtuelcom

tinyMCE.addToLang('',{
insertdate_desc : 'Ins�rer la date',
inserttime_desc : 'Ins�rer l\'heure',
inserttime_months_long : new Array("Janvier", "F�vrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Ao�t", "Septembre", "Octobre", "Novembre", "D�cembre"),
inserttime_months_short : new Array("Jan", "Fev", "Mar", "Avr", "Mai", "Juin", "Juil", "Aout", "Sep", "Oct", "Nov", "Dec"),
inserttime_day_long : new Array("Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"),
inserttime_day_short : new Array("Lun", "Mar", "Mer", "Jeu", "Thu", "Ven", "Sam", "Dim")
});
