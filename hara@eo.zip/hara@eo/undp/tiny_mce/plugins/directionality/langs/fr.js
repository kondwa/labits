// Traduit par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Vers la droite',
directionality_rtl_desc : 'Vers la gauche'
});
