/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Authors :
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * Last Updated : November 26, 2005
 * TinyMCE Version : 2.0RC4
 */
tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direcionamento da esquerda para direita',
directionality_rtl_desc : 'Direcionamento da direita para esquerda'
});
