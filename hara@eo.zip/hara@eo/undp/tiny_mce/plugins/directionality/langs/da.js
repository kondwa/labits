// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Retning - venstre mod h&oslash;jre',
directionality_rtl_desc : 'Retning - h&oslash;jre mod venstre'
});
