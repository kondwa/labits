// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
paste_text_desc : 'Skeyta texta eing&ouml;ngu',
paste_text_title : 'Nota�u CTRL+V � lyklabor�inu til a� skeyta textanum � gluggann.',
paste_text_linebreaks : 'Halda l&iacute;nubilum',
paste_word_desc : 'Skeyta &uacute;r Word',
paste_word_title : 'Nota�u CTRL+V � lyklabor�inu til a� skeyta textanum � gluggann.',
selectall_desc : 'Velja allt'
});
