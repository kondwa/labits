// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('',{
paste_text_desc : '採純文字模式貼上',
paste_text_title : '使用鍵盤上的 CTRL+V 組合鍵將文字貼入作業區中',
paste_text_linebreaks : '保留換行符號',
paste_word_desc : '自 Word 內轉貼',
paste_word_title : '使用鍵盤上的 CTRL+V 組合鍵將文字貼入作業區中',
selectall_desc : '全選'
});
