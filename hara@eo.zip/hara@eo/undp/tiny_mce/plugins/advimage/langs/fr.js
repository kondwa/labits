// Modifier par Mathieu Gautheret

tinyMCE.addToLang('advimage',{
tab_general : 'G�n�rale',
tab_appearance : 'Apparence',
tab_advanced : 'Avanc�e',
general : 'G�n�rale',
title : 'Titre',
preview : 'Pr�visualisation',
constrain_proportions : 'Conserver les proportions',
langdir : 'Sens d\'�criture',
langcode : 'Code de langue du libell�',
long_desc : 'Description du lien',
style : 'Style',
classes : 'Classes',
ltr : 'De gauche � droite',
rtl : 'De droite � gauche',
id : 'Id',
image_map : 'Image map',
swap_image : 'Image d\'�change',
alt_image : 'Image alternative',
mouseover : 'Quand le pointeur est au dessus',
mouseout : 'Quand le pointeur est en dehors',
misc : 'Divers',
example_img : 'Apparence&nbsp;pr�visualisation&nbsp;image',
missing_alt : 'Etes vous sur de vouloir continuer sans inclure une description de l\'image. Cette description est utile pour les utilisateurs ne pouvant pas afficher les images ou les ayant d�sactiv�es.'
});