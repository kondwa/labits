// SI lang variables ISO-8859-2

tinyMCE.addToLang('advimage',{
tab_general : 'Splo&#353;no',
tab_appearance : 'Izgled',
tab_advanced : 'Napredno',
general : 'Splo&#353;no',
title : 'Naslov',
preview : 'Predogled',
constrain_proportions : 'Zakleni razmerje',
langdir : 'Smer jezika',
langcode : 'Koda jezika',
long_desc : 'Povezava do podrobnega opisa',
style : 'Stil',
classes : 'Razredi',
ltr : 'Od leve proti desni',
rtl : 'Od desne proti levi',
id : 'Id',
image_map : 'Ime zemljevida',
swap_image : 'Zamenjava slike',
alt_image : 'Alternativna slika',
mouseover : 'ko gre mi&#353; &#269;ez sliko',
mouseout : 'ko gre mi&#353; s slike',
misc : 'Razno',
example_img : 'Slika za predogled',
missing_alt : 'Ali ste prepri&#269;ani, da &#382;elite nadaljevati brez vnosa za opis slike? Brez njega bo slika mogo&#269;e nedosegljiva za uporabnike s posebnimi potrebami ali uporabnike s tekstovnimi brskalniki.'
});
