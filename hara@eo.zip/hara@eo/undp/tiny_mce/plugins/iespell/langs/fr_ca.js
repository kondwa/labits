// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15

tinyMCE.addToLang('',{
iespell_desc : 'Executer le v�rificateur d\'orthographe',
iespell_download : "ieSpell n\'a pas �t� trouv�. Cliquez sur OK pour aller au site de t�l�chargement."
});
