// TR lang variables

tinyMCE.addToLang('',{
preview_desc : '�nizleme'
});
