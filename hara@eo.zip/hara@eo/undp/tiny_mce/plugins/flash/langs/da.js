// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('flash',{
title : 'Inds&aelig;t / rediger Flash-film',
desc : 'Inds&aelig;t / rediger Flash-film',
file : 'Flash-Fil (.swf)',
size : 'St&oslash;rrelse',
list : 'Flash filer',
props : 'Flash egenskaber',
general : 'Genererelt'
});
