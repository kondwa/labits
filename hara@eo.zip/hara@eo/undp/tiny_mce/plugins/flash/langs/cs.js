/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.7 2006/01/11 14:25:48 spocke Exp $ 
 */  

tinyMCE.addToLang('flash',{
title : 'Vlo�it / editovat Flash',
desc : ''Vlo�it / editovat Flash ',
file : 'Flash soubor (.swf)',
size : 'Velikost',
list : 'Flash soubory',
props : 'Flash nastaven�',
general : 'Obecn�'
});
