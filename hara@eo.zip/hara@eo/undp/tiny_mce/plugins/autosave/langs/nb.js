// nb = Norwegian (bokm&aring;l) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
autosave_unload_msg : 'Forandringene du gjorde forsvinner om du velger &aring; forlate denne siden.'
});

