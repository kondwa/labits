// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('',{
autosave_unload_msg : '所有已作的改變會因您離開此頁面而自動放棄不儲存'
});
