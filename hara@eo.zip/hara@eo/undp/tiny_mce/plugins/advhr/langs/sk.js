/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: sk.js,v 1.1 2005/11/22 20:56:43 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vložiť/editovať vodorovný oddeľovač',
insert_advhr_width : 'Šírka',
insert_advhr_size : 'Výška',
insert_advhr_noshade : 'Nestieňovať'
});

