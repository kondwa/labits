// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vstavi/uredi vodorano &#269;rto',
insert_advhr_width : '&#352;irina',
insert_advhr_size : 'Vi&#353;ina',
insert_advhr_noshade : 'Brez sence'
});
