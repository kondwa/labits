// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('',{
insert_advhr_desc : 'Inds&aelig;t / rediger horisontal linie',
insert_advhr_width : 'Bredde',
insert_advhr_size : 'H&oslash;jde',
insert_advhr_noshade : 'Ingen skygge'
});
