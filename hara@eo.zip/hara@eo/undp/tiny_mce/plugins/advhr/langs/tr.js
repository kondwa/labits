// TR lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Yatay �izgi ekle/d�zenle',
insert_advhr_width : 'Geni�lik',
insert_advhr_size : 'Y�kseklik',
insert_advhr_noshade : 'G�lge yok'
});
