// RU lang variables UTF-8

tinyMCE.addToLang('',{
save_desc : 'Сохранить'
});
