// HE lang variables by Liron Newman, http://eesh.net

tinyMCE.addToLang('',{
save_desc : '����'
});
