// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('',{
fullscreen_title : 'Fuldsk&aelig;rmstilstand',
fullscreen_desc : 'T&aelig;nd / sluk for fuldsk&aelig;rm'
});
