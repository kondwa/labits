// UK lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Dull sgr&icirc;n-lawn',
fullscreen_desc : 'Gwrthdroi dull sgr&icirc;n-lawn'
});
