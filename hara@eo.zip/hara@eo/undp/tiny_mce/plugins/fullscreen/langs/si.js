// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
fullscreen_title : 'Celozaslonski na&#269;in',
fullscreen_desc : 'Vklopi/izklopi celozaslonski na&#269;in'
});
