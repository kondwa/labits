// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('',{
fullscreen_title : 'Heilskj&aacute;r',
fullscreen_desc : 'Skipta &iacute; / &uacute;r heilskj&aacute;'
});
