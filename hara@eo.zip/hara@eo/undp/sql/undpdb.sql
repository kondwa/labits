-- MySQL dump 10.10
--
-- Host: localhost    Database: undp
-- ------------------------------------------------------
-- Server version	5.0.18-nt
DROP DATABASE IF EXISTS undp;
CREATE DATABASE undp;
GRANT ALL ON undp.* TO 'undpuser'@'localhost' identified by 'undpuserpassword','undpuser'@'%' identified by 'undpuserpassword';
USE undp;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) NOT NULL default '0',
  `title` varchar(55) NOT NULL default '',
  `startpage` varchar(55) NOT NULL default '',
  `keywords` text NOT NULL,
  `description` varchar(55) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `config`
--


/*!40000 ALTER TABLE `config` DISABLE KEYS */;
LOCK TABLES `config` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `config` ENABLE KEYS */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` int(11) NOT NULL auto_increment,
  `menuid` int(11) NOT NULL default '-2',
  `title` varchar(255) NOT NULL default '',
  `last_updated` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `posting_time` timestamp NOT NULL default '0000-00-00 00:00:00',
  `text` text NOT NULL,
  `keywords` text NOT NULL,
  `position` tinyint(4) NOT NULL default '0',
  `changed` tinyint(4) NOT NULL default '0',
  `gran` varchar(55) NOT NULL default '0',
  `sector` varchar(40) default NULL,
  `cso` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 PACK_KEYS=0;

--
-- Dumping data for table `content`
--


/*!40000 ALTER TABLE `content` DISABLE KEYS */;
LOCK TABLES `content` WRITE;
INSERT INTO `content` VALUES (1,2,'MDG Goal 1','2006-02-22 13:47:06','0000-00-00 00:00:00','        <h3 align=\"center\">Goal 1: Eradicate Extreme Poverty and Hunger<br />  </h3> <h4>Targets:</h4>  <ul>   <li> Halve, between 1990 and 2015, the proportion of people whose income is less than one dollar a day.</li>   <li>Halve, between 1990 and 2015, the proportion of people who suffer from hunger.  </li> </ul>','mdg,goal 1,poverty,hunger',0,0,'0',NULL,''),
(2,3,'MDG Goal 2','2006-02-22 13:47:06','0000-00-00 00:00:00','        <h3 align=\"center\">Goal 2: Achieve Universal Primary Education</h3> <h4>Target:</h4>  <ul>   <li>Ensure that, by 2015, children everywhere, boys and girls alike, will be able to complete a full course of primary education. </li> </ul>','mdg,goal 2,primary education',0,0,'0.,2',NULL,''),
(3,4,'MDG Goal 3','2006-02-22 13:47:06','0000-00-00 00:00:00','<h3 align=\"center\">Goal 3: Promote Gender Equality And Empower Women<br /> </h3> <h4>Target:</h4> <ul>   <li>Eliminate gender disparity in primary and secondary education preferably by 2005 and to all levels of education no later than 2015. <br />   </li> </ul>','mdg,goal 3,gender equality,women empowerment',0,0,'0',NULL,''),
(4,5,'MDG Goal 4','2006-02-22 13:47:06','0000-00-00 00:00:00','         <div align=\"center\"> <h3>Goal 4: Reduce Child Mortality</h3> </div> <h4>Target:</h4>  <ul>   <li>Reduce by two-thirds, between 1990 and 2015, the under-five mortality rate. </li> </ul>','mdg,goal 4,child mortality',0,0,'0.,4',NULL,''),
(5,6,'MDG Goal 5','2006-02-22 13:47:06','0000-00-00 00:00:00','<h3 align=\"center\">Goal 5: Improve Maternal Health</h3> <h4>Target:</h4> <ul>   <li>Reduce by three-quarters, between 1990 and 2015, the maternal mortality ratio.<br />   </li> </ul>','mdg,goal 5,maternity health',0,0,'0',NULL,''),
(6,7,'MDG Goal 6','2006-02-22 13:47:06','0000-00-00 00:00:00','<h3 align=\"center\">Goal 6: Combat HIV/AIDS, Malaria And Other Diseases</h3> <h4>Targets:</h4> <ul>   <li>Have halted by 2015 and begun to reverse the spread of HIV/AIDS.</li>   <li>Have halted by 2015 and begun to reverse the incidence of malaria and other major diseases.<br />   </li> </ul>','mdg,goal 6,hiv,aids,malaria,diseases',0,0,'0.,6',NULL,''),
(7,8,'MDG Goal 7','2006-02-22 13:47:06','0000-00-00 00:00:00','        <h3 align=\"center\">Goal 7: Ensure Environmental Sustainbility</h3> <h4>Target:</h4> <ul>   <li>Integrate the principles of sustainable development into the country policies and programmes and reverse the loss of environmental resources</li><li>Halve, by 2015, the proportion of people without sustainable access to safe drinking water.</li><li>By 2020, to have achieved a significant improvement in the lives of at least 100 million slum dwellers. <br />   </li>   </ul>','mdg,goal 7,environment',0,0,'0',NULL,''),
(8,9,'MDG Goal 8','2006-02-22 13:47:06','0000-00-00 00:00:00','<h3 align=\"center\">Goal 8: Develop a Global Paternership for Development</h3> <h4>Targets:</h4> <ul>   <li>Develop further an open, rule-based, predictable, non-discriminatory trading and financial system.</li><li>Address the Special Needs of the Least Developed Countries.</li>   <li>Address the Special Needs of landlocked countries and small island developing states.</li>   <li>Deal comprehensively with the debt problems of developing countries through national and international measures in order to make debt sustainable in the long term. <br />   </li>   <li>In cooperation with developing countries, develop and implement strategies for decent and productive work for youth.</li>   <li>In cooperation with pharmaceutical companies, provide access to affordable, essential drugs in developing countries. <br />   </li>   <li>In cooperation with the private sector, make available the benefits of new technologies, especially information and communications.&nbsp;</li>  </ul>','mdg,goal 8,development,global partenership',0,0,'0',NULL,'');
UNLOCK TABLES;
/*!40000 ALTER TABLE `content` ENABLE KEYS */;

--
-- Table structure for table `menus`
--

DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL auto_increment,
  `pid` varchar(255) NOT NULL default '',
  `pos` int(11) NOT NULL default '0',
  `name` varchar(55) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `title` varchar(55) NOT NULL default '',
  `target` varchar(55) NOT NULL default '',
  `icon` varchar(255) NOT NULL default '',
  `iconOpen` varchar(255) NOT NULL default '',
  `open` tinyint(4) NOT NULL default '0',
  `nxt` int(11) NOT NULL default '1',
  `changed` int(2) NOT NULL default '0',
  `kids` int(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menus`
--


/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
LOCK TABLES `menus` WRITE;
INSERT INTO `menus` VALUES (1,'',0,'Millenium Development Goals','','','','','',0,7,0,6),
(2,'0.',1,'MDG Goal 1','page.php?cid=1','Eradicate extreme poverty and hunger','','','',0,6,0,5),
(3,'0.',2,'MDG Goal 2','page.php?cid=2','Achieve universal primary education','','','',0,2,0,1),
(4,'0.',3,'MDG Goal 3','page.php?cid=3','Promote gender equality and empower women','','','',0,3,0,2),
(5,'0.',4,'MDG Goal 4','page.php?cid=4','Reduce child mortality','','','',0,1,0,0),
(6,'0.',5,'MDG Goal 5','page.php?cid=5','Improve maternal health','','','',0,4,0,3),
(7,'0.',6,'MDG Goal 6','page.php?cid=6','Combat HIV/AIDS, malaria and other diseases','','','',0,5,0,0),
(8,'0.',7,'MDG Goal 7','page.php?cid=7','Ensure environment sustainability','','','',0,2,0,1),
(9,'0.',8,'MDG Goal 8','page.php?cid=8','Develop a global partenship for development','','','',0,2,0,1);
UNLOCK TABLES;
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;

--
-- Table structure for table `organisation`
--

DROP TABLE IF EXISTS `organisation`;
CREATE TABLE `organisation` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(200) collate latin1_general_ci NOT NULL,
  `acronym` varchar(20) collate latin1_general_ci default '',
  `email` varchar(200) collate latin1_general_ci default NULL,
  `website` text collate latin1_general_ci,
  `sector` text collate latin1_general_ci,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `organisation`
--


/*!40000 ALTER TABLE `organisation` DISABLE KEYS */;
LOCK TABLES `organisation` WRITE;
UNLOCK TABLES;
/*!40000 ALTER TABLE `organisation` ENABLE KEYS */;

--
-- Table structure for table `sectors`
--

DROP TABLE IF EXISTS `sectors`;
CREATE TABLE `sectors` (
  `sector` varchar(200) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sectors`
--


/*!40000 ALTER TABLE `sectors` DISABLE KEYS */;
LOCK TABLES `sectors` WRITE;
INSERT INTO `sectors` VALUES ('Agriculture'),
('Child Protection'),
('Demography'),
('Economy'),
('Education'),
('Environment'),
('Governance'),
('Health'),
('Information and communication'),
('Labour'),
('Mining and Quarrying'),
('Nutrition'),
('Soc. Services and Comm. Dev.'),
('Tourism'),
('Transport'),
('Women');
UNLOCK TABLES;
/*!40000 ALTER TABLE `sectors` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(255) NOT NULL default '',
  `pass` varchar(255) NOT NULL default '',
  `opts` varchar(255) NOT NULL default '',
  `status` int(4) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--


/*!40000 ALTER TABLE `users` DISABLE KEYS */;
LOCK TABLES `users` WRITE;
INSERT INTO `users` VALUES (1,'admin','undpadmin','',1);
UNLOCK TABLES;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

