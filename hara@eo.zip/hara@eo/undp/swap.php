<?
include("config.php");
database_connect();

function swap_nodes($id_1, $id_2){
    //get the 1st node
	$qry = "select pos from menus where id=$id_1";
	if(!$res = mysql_query($qry)){
		print mysql_error();
		exit;
	}
	$row1 = mysql_fetch_assoc($res)

    //get the 2nd node
    $qry = "select pos from menus where id=$id_2";
    if(!$res = mysql_query($qry)){
		print mysql_error();
		exit;
	}
    $row2 = mysql_fetch_assoc($res)
     
    // do the swap
    $qry = "update menus set pos = $row1[0] where id=$id2";
    if (!$res = mysql_query($qry)){
        print mysql_error();
        exit
    }

    $qry = "update menus set pos = $row2[0] where id=$id1";
    if (!$res = mysql_query($qry)){
        print mysql_error();
        exit
    }
?>
