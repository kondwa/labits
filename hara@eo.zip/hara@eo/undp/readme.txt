0. ensure that php-mysql is available, need to restart web server
1. create the dtabase, user ,password as in the library/config.php file
	mysqladmin create <dbname>
	mysql> grant all privileges on <dbname>.* to '<username>'@localhost identified by 	'<password>'
2. the 
--------------
3. use the install.php file to create the database ...
4. want to have the menus read from teh db, altered as well: suggests the folloing structure:

id  	Number 	Unique identity number.
pid 	Number 	Number refering to the parent node. The value for the root node has to be -1.
name 	String 	Text label for the node.
url 	String 	Url for the node.
title 	String 	Title for the node.
target 	String 	Target for the node.
icon 	String 	Image file to use as the icon. Uses default if not specified.
iconOpen 	String 	Image file to use as the open icon. Uses default if not specified.
open 	Boolean 	Is the node open.

"CREATE TABLE `menus` (
  `id` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL default '-1',
  `position` int(11) NOT NULL default 0,
  `name` varchar(255) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `target` varchar(255) NOT NULL default '',
  `icon` varchar(255) NOT NULL default '',
  `iconOpen` varchar(255) NOT NULL default '',
  `open`  tinyint(4) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;";

OK - changed this substantially - see undpdb.sql, which should later be incorporated into the installation/install.php script

algorithm for converting menus table entires to actuall dtree commands - this is pure php!

  `id` `pid` `position` `name` `url` `title` `target` `icon` `iconOpen` `open` 
(`id`,`pid`,`position`,`name`,`url`,`title`,`target`,`icon`,`iconOpen`,`open`)
---------------------------------------	
  d = new dTree('d');
  d.config.target='rechts';

  d.add(0,-1,'NGO Listing');		('',-1,0,'NGO Listing');
  d.add(1,0,'Node 1','');		('',0,0,'Node 1','');		
  d.add(2,0,'Node 2','bogus.html');	('',0,1,'Node 2','bogus.html');
  d.add(3,1,'Node 1.1','');		('',1,0,'Node 1.1','');
  d.add(4,0,'Node 3','example01.html');	('',0,2,'Node 3','example01.html');
  d.add(5,3,'Node 1.1.1','');		('',3,0,'Node 1.1.1','');
  d.add(6,5,'Node 1.1.1.1','example01.html');	('',5,0,'Node 1.1.1.1','example01.html');
  d.add(7,0,'Node 4','example01.html');	('',0,3,'Node 4','example01.html');
  d.add(8,1,'Node 1.2','example01.html'); ('',1,1,'Node 1.2','example01.html');
  d.add(9,0,'My Pictures','example01.html','Pictures I\'ve taken over the years','','','dtree/img/imgfolder.gif');		('',0,4,'My Pictures','example01.html','Pictures I\'ve taken over the years','','','dtree/img/imgfolder.gif');
  d.add(10,9,'The trip to Iceland','example01.html','Pictures of Gullfoss and Geysir');		('',9,0,'The trip to Iceland','example01.html','Pictures of Gullfoss and Geysir');
  d.add(11,9,'Mom\'s birthday','example01.html');	('',9,1,'Mom\'s birthday','example01.html');
  d.add(12,0,'Recycle Bin','example01.html','','','dtree/img/trash.gif');	('',0,5,'Recycle Bin','example01.html','','','dtree/img/trash.gif');

		document.write(d);
---------------------------------------
New setup:

(`id`,`position`,`name`,`url`,`title`,`target`,`icon`,`iconOpen`,`open`)

insert into menus values ('','','NGO Listing','','','','','','');
insert into menus values ('','.1','Node 1','','','','','','');		
insert into menus values ('','.2','Node 2','bogus.html','','','','','');
insert into menus values ('','.3','Node 3','example01.html','','','','','');
insert into menus values ('','.4','Node 4','example01.html','','','','','');
insert into menus values ('','.5','Node 5','example01.html','Pictures I\'ve taken over the years','','','dtree/img/imgfolder.gif','');
insert into menus values ('','.6','Node 6','example01.html','','','dtree/img/trash.gif','','');
insert into menus values ('','1.1','Node 1.1','','','','','','');
insert into menus values ('','1.2','Node 1.2','example01.html','','','','','');
insert into menus values ('','1.1.1','Node 1.1.1','','','','','','');
insert into menus values ('','1.1.1.1','Node 1.1.1.1','example01.html','','','','','');
insert into menus values ('','5.1','Node 5.1','example01.html','Pictures of Gullfoss and Geysir','','','','');
insert into menus values ('','5.2','Node 5.2','example01.html','','','','','');

------------------------------------------------------
Or ...
Here, we have field PID as a character string

(`id`,`pid`,`position`,`name`,`url`,`title`,`target`,`icon`,`iconOpen`,`open`)

insert into menus values ('','','','NGO Listing','','','','','','');
insert into menus values ('','','1','Node 1','','','','','','');		
insert into menus values ('','','2','Node 2','bogus.html','','','','','');
insert into menus values ('','','3','Node 3','bogus.html','','','','','');
insert into menus values ('','','4','Node 4','bogus.html','','','','','');
insert into menus values ('','','5','Node 5','bogus.html','Pictures I\'ve taken over the years','','','dtree/img/imgfolder.gif','');
insert into menus values ('','','6','Node 6','bogus.html','','','dtree/img/trash.gif','','');
insert into menus values ('','.1','1','Node 1.1','','','','','','');
insert into menus values ('','.1','2','Node 1.2','bogus.html','','','','','');
insert into menus values ('','.1.1','1','Node 1.1.1','','','','','','');
insert into menus values ('','.1.1.1','1','Node 1.1.1.1','bogus.html','','','','','');
insert into menus values ('','.5','1','Node 5.1','bogus.html','Pictures of Gullfoss and Geysir','','','','');
insert into menus values ('','.5','2','Node 5.2','bogus.html','','','','','');

------------------------------------------------------------------
better - why the distinguished positio of the first element? 
need to have the `position` field be integral to get the 'next in sequence'
encode the pid/pos pair so that concat (pid,pos) yields the 'direct code':

so (1.2.,3) --> 1.2.3
which has parent (1.,2) 
which has parent ('',1)  <--- this nw is 'the' root
although we now have the option of producing a second tree base on ('',2)

+ note that what we need to do is 
o) convert these codes --> dtree codes	==> OK
i) create a new child of existing node 	
	// all these require carrying extra info: introduce `nxt`
ii) identify a leaf 
iii) delete a leaf (ONLY)
iv) shift a leaf up/down one position

(`id`,`pid`,`pos`,`name`,`url`,`title`,`target`,`icon`,`iconOpen`,`open`, `nxt`)

insert into menus values ('','',1,'NGO Listing','','','','','','');
insert into menus values ('','1.',1,'Node 1','','','','','','');		
insert into menus values ('','1.',2,'Node 2','bogus.html','','','','','');
insert into menus values ('','1.',3,'Node 3','bogus.html','','','','','');
insert into menus values ('','1.',4,'Node 4','bogus.html','','','','','');
insert into menus values ('','1.',5,'Node 5','bogus.html','Pictures I\'ve taken over the years','','','dtree/img/imgfolder.gif','');
insert into menus values ('','1.',6,'Node 6','bogus.html','','','dtree/img/trash.gif','','');
insert into menus values ('','1.1.',1,'Node 1.1','','','','','','');
insert into menus values ('','1.1.',2,'Node 1.2','bogus.html','','','','','');
insert into menus values ('','1.1.1.',1,'Node 1.1.1','','','','','','');
insert into menus values ('','1.1.1.1.','1','Node 1.1.1.1','bogus.html','','','','','');
insert into menus values ('','1.5.','1','Node 5.1','bogus.html','Pictures of Gullfoss and Geysir','','','','');
insert into menus values ('','1.5.','2','Node 5.2','bogus.html','','','','','');

CREATE TABLE `menus` (
  `id` int(11) NOT NULL auto_increment,
  `pid` varchar(255) NOT NULL default '',
  `pos` int(11) NOT NULL default 0,
  `name` varchar(255) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `target` varchar(255) NOT NULL default '',
  `icon` varchar(255) NOT NULL default '',
  `iconOpen` varchar(255) NOT NULL default '',
  `open`  tinyint(4) NOT NULL default '',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;";

note that we should be able to run more than a single menu with the same db
- OK; works

- decided to add extra column tp menus to accomodate identifying leaves etc. see how insert.php now works ...

=======================================
+ fixed soem references to unset variables ($_GET, $_POST) --> use isset($_?[])
+ want to have the tree carry a url at 'each' node - so that we only open by 
clicking the '+'  or '-' icons: this allows us to carry NGO detail at the node itself ...
+ want to use the three.php style for editing - and display 'non-menu' files in the third frame ..
+ setup users table ...

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(255) NOT NULL default '',
  `pass` varchar(255) NOT NULL default '',
  `opts` varchar(255) NOT NULL default '',
  `status` int(2) NOT NULL default 0,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;";

then we use the following construction:

$srcpid = '0.3.';
$srcpos = '1';
$desc = $srcpid.$srcpos.'%';
$parpid = explode ('.',$srcpid); 

$sql =  "SELECT * from menus WHERE ";
// we want the sql that extracts 
// 1. this node, (an NGO x)
$sql .= "pid='$srcpid' AND pos='$srcpos' ";	
// 2. all its descendants (if any)
$sql .= "OR ( pid like '$desc') ";
// 3. the line up to the root ( its GOAL )
$par = $parpid[0].'.'; $parpos = $parpid[1];
$sql .= "OR ( pid ='$par' and pos='$parpos' )"; 

//'' 0
//0. 3
//0.3. 1 <--- us

for applications, we make this a function, since we will present several different NGOS (potentially)
+ trouble with moderation when editing takes place _before_ a copy is placed in /cache: change this in the edit.php script?
