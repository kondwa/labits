<?php
    require_once("config.php");
    database_connect();
    $id=$mid=$title=$lastupdated=$postingtime=$text=$keywords=$position=$status='';
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Editing : <?=($title)?"[$title]":"[organisation profile]";?></title>
<!-- TinyMCE -->
<script language="javascript" type="text/javascript" src="tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
	tinyMCE.init({
		mode : "specific_textareas",
		theme : "advanced",
		plugins : "table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,zoom,flash,searchreplace,print,contextmenu,paste,directionality,fullscreen",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,zoom,separator,forecolor,backcolor",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,flash,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		content_css : "example_word.css",
	    plugi2n_insertdate_dateFormat : "%Y-%m-%d",
	    plugi2n_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		external_link_list_url : "get_lists.php",
		external_image_list_url : "example_image_list.js",
		flash_external_list_url : "example_flash_list.js",
		file_browser_callback : "fileBrowserCallBack",
		paste_use_dialog : false,
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,
		theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",
		paste_auto_cleanup_on_paste : true,
		paste_convert_headers_to_strong : false,
		paste_strip_class_attributes : "all"
	});

	function fileBrowserCallBack(field_name, url, type, win) {
		// This is where you insert your custom filebrowser logic
		alert("Filebrowser callback: field_name: " + field_name + ", url: " + url + ", type: " + type);

		// Insert new URL, this would normaly be done in a popup
		win.document.forms[0].elements[field_name].value = "someurl.htm";
	}
</script>

<!-- /TinyMCE -->
<link rel="StyleSheet" href="main.css" type="text/css" />
<style type="text/css">
<!--
.style1 {font-size: 14px}
-->
</style>
</head>

<body background="./images/int1_back.gif" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div align=center>
<!-- table width="<? echo "$fwdth" ?>" border="0" cellpadding="0" cellspacing="0" background="./images/int1_topback.gif" -->
<table width=<? echo "$fwdth"; ?> border="0" align="center" class="hoofdtabel">
<form method="post" action="signup2.php">
    <tr><td colspan="2"><h3 align="center" class="titel1 style1">CSO Database - Collection Form </h3></td>
    </tr>
    <tr align="right">
      <td colspan="2"><a href="./index.php" class="titel2">Home</a> | <a href="./help.php#signup" class="titel2">Help</a> </td>
    </tr>
    <tr>
      <td colspan="2"><strong>Step 1 of 2 </strong></td>
    </tr>
    <tr>
      <td colspan="2"><div align="center" class="titel1"><strong>Create or Paste the Organisation Profile in the space below: </strong></div></td>
    </tr>
    <tr>
      <td height="17" colspan="2">&nbsp;</td>
    </tr>
    <tr><td><strong>Title</strong></td>
    <td>
<input name=title value="<?=$title;?>" size="81">	</td></tr>
    <!--tr><td>Posted</td>
      <td><input disabled name=time></td></tr-->
    <tr><td><strong>Keywords</strong></td>
    <td><textarea  name=keywords cols=80 rows=1><?=$keywords;?></textarea></td><tr>
      <td>Content</td><td><textarea id="text" name="text" rows="20" cols="80" style="width:100%" mce_editable="true">
        <?=$text;?>
	    </textarea></td>
    <tr><td colspan=2 align=right>&nbsp;</td>
      </tr>
    <tr>
      <td colspan=2 align=right><div align="left">Number of Studies/Projects/Publications done by the organisatio
          <input name="projs" type="text" id="projs" size="3">
      </div></td>
    </tr>
    <tr>
      <td colspan=2 align=right><input type=hidden name=signup value=true>
        <input name="submit" type="submit" value="Submit" />
        <input type="reset" name="reset" value="Reset" /></td>
    </tr>
</form>
</table>
</div>
</body>
</html>
