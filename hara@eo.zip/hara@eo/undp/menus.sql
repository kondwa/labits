-- MySQL dump 10.9
--
-- Host: localhost    Database: undp
-- ------------------------------------------------------
-- Server version	4.1.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menus`
--
use undp;OB
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL auto_increment,
  `pid` varchar(255) NOT NULL default '',
  `pos` int(11) NOT NULL default '0',
  `name` varchar(55) NOT NULL default '',
  `url` varchar(255) NOT NULL default '',
  `title` varchar(55) NOT NULL default '',
  `target` varchar(55) NOT NULL default '',
  `icon` varchar(255) NOT NULL default '',
  `iconOpen` varchar(255) NOT NULL default '',
  `open` tinyint(4) NOT NULL default '0',
  `nxt` int(11) NOT NULL default '1',
  `changed` int(2) NOT NULL default '0',
  `kids` int(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menus`
--


/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
LOCK TABLES `menus` WRITE;
INSERT INTO `menus` VALUES (1,'',0,'Millenium Development Goals','','','','','',0,7,0,6),(2,'0.',1,'Goal 1','bogus.html','','','','',0,5,0,4),(3,'0.',2,'Goal 2','page.php?cid=1','','','','',0,1,0,0),(4,'0.',3,'Goal 3','','','','','',0,2,0,1),(5,'0.',4,'Goal 4','page.php?cid=4','','','','',0,1,0,0),(6,'0.',5,'Goal 5','','Pictures I\'ve taken over the years','','','dtree/img/imgfolder.gif',0,4,0,3),(7,'0.',6,'Node 6','page.php?cid=5','','','dtree/img/trash.gif','',0,5,0,0),(8,'0.1.',1,'NGO 1','','','','','',0,2,0,1),(9,'0.1.',2,'NGO 2','page.php?cid=10','','','','',0,1,0,0),(10,'0.1.1.',1,'Project A','page.php?cid=9','','','','',0,2,0,0),(12,'0.5.',1,'NGO 1','page.php?id=12','Pictures of Gullfoss and Geysir','','','',0,1,0,0),(13,'0.5.',2,'NGO 4','page.php?cid=7','','','','',0,1,0,0),(14,'0.1.',3,'NGO 3','page.php?cid=12','','','','',0,1,0,0),(15,'0.1.',4,'NGO 4','page.php?id=15','','','','',0,1,0,0),(16,'0.5.',3,'NGO 5','page.php?cid=6','','','','',0,1,0,0),(17,'0.3.',1,'NGO 2','page.php?cid=11','','','','',0,1,0,0);
UNLOCK TABLES;
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

