<?php
    require_once("config.php");
    database_connect();
    $id=$mid=$title=$lastupdated=$postingtime=$text=$keywords=$position=$status=$cso='';
    if($_GET){
        if($_GET['id']){
            $cid=$_GET['id'];
            $qry="SELECT * FROM content WHERE id=$cid";
            if(!$res=mysql_query($qry)){ print mysql_error(); exit; }

            if($row=mysql_fetch_assoc($res)){
                $id=$row['id'];
                $menuid=$row['menuid'];
                $title=$row['title'];
                $lastupdated=$row['last_updated'];
                $postingtime=$row['posting_time'];
                $text=$row['text'];
                $keywords=$row['keywords'];
                $position=$row['position'];
				$cso=$row['cso'];
                #$status=$row['status'];
            }
        }elseif($_GET['mid']){
		//creating new content
            $mid=$_GET['mid'];
        }
    }
    
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Editing : <?=($title)?"[$title]":"[new document]";?></title>
<!-- TinyMCE -->
<script language="javascript" type="text/javascript" src="tiny_mce/tiny_mce.js"></script>
<script language="javascript" type="text/javascript">
	tinyMCE.init({
		mode : "specific_textareas",
		theme : "advanced",
		plugins : "table,save,advhr,advimage,advlink,emotions,iespell,insertdatetime,preview,zoom,flash,searchreplace,print,contextmenu,paste,directionality,fullscreen",
		theme_advanced_buttons1_add_before : "save,newdocument,separator",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,insertdate,inserttime,preview,zoom,separator,forecolor,backcolor",
		theme_advanced_buttons2_add_before: "cut,copy,paste,pastetext,pasteword,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator",
		theme_advanced_buttons3_add : "emotions,iespell,flash,advhr,separator,print,separator,ltr,rtl,separator,fullscreen",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		content_css : "example_word.css",
	    plugi2n_insertdate_dateFormat : "%Y-%m-%d",
	    plugi2n_insertdate_timeFormat : "%H:%M:%S",
		extended_valid_elements : "hr[class|width|size|noshade],font[face|size|color|style],span[class|align|style]",
		external_link_list_url : "get_lists.php",
		external_image_list_url : "example_image_list.js",
		flash_external_list_url : "example_flash_list.js",
		file_browser_callback : "fileBrowserCallBack",
		paste_use_dialog : false,
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,
		theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",
		paste_auto_cleanup_on_paste : true,
		paste_convert_headers_to_strong : false,
		paste_strip_class_attributes : "all"
	});

	function fileBrowserCallBack(field_name, url, type, win) {
		// This is where you insert your custom filebrowser logic
		alert("Filebrowser callback: field_name: " + field_name + ", url: " + url + ", type: " + type);

		// Insert new URL, this would normaly be done in a popup
		win.document.forms[0].elements[field_name].value = "someurl.htm";
	}

    function filTime(){
        document.forms[0].time.value=new Date();
        setTimeout('filTime()',1000);
    }
    window.onload=filTime
</script>

<!-- /TinyMCE -->
<link rel="StyleSheet" href="main.css" type="text/css" />
</head>

<!-- body background="./images/int1_back.gif" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" -->
<body>
<div align=center>
<!-- table width="<? echo "$fwdth" ?>" border="0" cellpadding="0" cellspacing="0" background="./images/int1_topback.gif" -->
<table width=<? echo "$fwdth"; ?> border="0" align="center" class="hoofdtabel">
<form method="post" action="index.php">
    <tr><td><h1>&nbsp;</h1></td>
    <td><?=$msg;?></td>
    </tr>
    <tr><td>Title</td><td>
<input name=title value="<?=$title;?>">
<input type=hidden name=id value=<?=$id;?>>
<input type=hidden name=menuid value="<?=$menuid;?>">
<input name="cso" type="hidden" id="cso" value="<?=$cso;?>">
<input type=hidden name=mid value="<?=$mid;?>">
    </td>
    </tr>
    <!--tr><td>Posted</td>
      <td><input disabled name=time></td>
    </tr-->
    <tr><td>Keywords</td><td><textarea  name=keywords cols=80 rows=1><?=$keywords;?></textarea></td><tr>
	<tr><td>Text</td><td>
        <textarea id="text" name="text" rows="20" cols="80" style="width:100%" mce_editable="true">
        <?=$text;?>
	    </textarea>
    </td><tr>
	<tr><td colspan=2 align=right><input type=hidden name=save value=true><input type="submit" value="Submit" />
	<input type="reset" name="reset" value="Reset" /></td></tr>
</form>
</table>
</div>
</body>
</html>
