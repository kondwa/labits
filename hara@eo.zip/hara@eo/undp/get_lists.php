<?php
$one= 'http://one.com';
		//external_image_list_url : "example_image_list.js",
		//external_link_list_url : "example_link_list.js",
?>
var tinyMCELinkList = new Array(
	// Name, URL
	["one", "<?=$one;?>"],
	["two", "http://www.freshmeat.com"],
	["three", "http://www.sourceforge.com"]
);
