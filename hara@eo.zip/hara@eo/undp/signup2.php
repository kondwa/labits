<?
	
	require_once('lib/insert.php');
	database_connect();
	$nodename='';
	$msg='';
if(isset($_POST['signup'])){
	$_=$_POST;
	$cid="";
	$_['text']=addslashes($_['text']);
	$_['title']=addslashes($_['title']);
	$time=time();

	$qry="INSERT INTO content(title,posting_time,keywords,text,changed) VALUES('$_[title]','$time','$_[keywords]','$_[text]',1)";
	if(!mysql_query($qry)){ print mysql_error();exit;}
		
	$cid = mysql_insert_id();
}
	function get_goal($no){
		$query="SELECT id,name,title FROM menus WHERE pid='0.'";
		if(!$res=mysql_query($query)){print mysql_error; exit;}
		$list="<select name='mdg$no' style='font-size:9px'><option value=''>select goal</option>";
		while($row=mysql_fetch_assoc($res)){
			$list .= "<option value='$row[id]'>$row[name]: $row[title]</option>";
		}
		$list .= "</select>";
		return $list;
	}

	function sectors(){
		$query="select sector from sectors";
		if(!$res=mysql_query($query)){print mysql_error(); exit;}
		$cnt=0; $list="<table>";
		while($row=mysql_fetch_assoc($res)){
			if(($cnt % 2) == 0){
				$list .= "<tr><td><input name='sector[]' type='checkbox' value='$row[sector]'>$row[sector]</td>";
			}else{
				$list .= "<td><input name='sector[]' type='checkbox' value='$row[sector]'>$row[sector]</td></tr>";
			}
			$cnt++;
		}
		$list .= "</table>";
		return $list;
	}
	function lsprojs(){
		$n=$_POST['projs'];
		for($i=1;$i<=$n;$i++){
			$no=($i<10)?"0$i":$i;
			$list.="$no.<input name='proj$i' size=10> - MDG:".get_goal($i)."<br>";
		}
//		$list.="<input type=hidden name=projs value=$n>";
		return $list;
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Sign up</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body background="./images/int1_back.gif">
<table width=<? echo "$fwdth"; ?> border="0" align="center">
<form action="index.php" method="post" name="frm">
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><h3 align="center">CSO Database -  Collection Form </h3>      </td>
    </tr>
  <tr align="right" bgcolor="#FFFFFF">
    <td colspan="2"><a href="./help.php#signup" class="titel2">Help</a></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><strong>Step 2 of 2</strong></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="156"><strong>Organisation:</strong></td>
    <td width="250"><input name="name" type="text" id="name" size="40"></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="156"><strong>Acronym:</strong></td>
    <td><input name="acronym" type="text" id="acronym" size="40"></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="156"><strong>Postal Address:</strong></td>
    <td><textarea name="address" cols="39" rows="2" id="address"></textarea></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="156"><strong>Email:</strong></td>
    <td><input name="email" type="text" id="email" size="40"></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td width="156"><strong>Website/URL:</strong></td>
    <td><input name="website" type="text" id="website" size="40"></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><hr></td>
    </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><strong>Login Details</strong>: (<em>to edit your organisation's information on the website</em>) </td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td><strong>Username:</strong></td>
    <td><input name="username" type="text" id="username"></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td><strong>Password:</strong></td>
    <td><input name="password" type="password" id="password"></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td><strong>Re-type Password: </strong></td>
    <td><input name="repassword" type="password" id="repassword"></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><hr></td>
  </tr>
  <!--tr bgcolor="#FFFFFF">
    <td colspan="2"><strong>Sector: </strong>(<em>Select the Sectors in which you are working </em>)</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><?=sectors();?></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><hr></td>
  </tr-->
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><strong>Studies/Projects/Publications:</strong></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2">
	<?=lsprojs();?>	</td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2"><hr></td>
  </tr>
  <tr bgcolor="#FFFFFF">
    <td colspan="2">
	<input type=hidden name=cid value="<?=$cid;?>"><input name="signup" type="hidden" id="signup">
    <input type="submit" value="submit">      
      <input name="reset" type="reset" value="reset"></td>
  </tr>
</form>
</table>
</body>
</html>
