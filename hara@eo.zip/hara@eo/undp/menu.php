<?php
session_start(); 

$edit=isset($_SESSION['loggedin']);
$opts = isset($_SESSION['opts']) ? $_SESSION['opts'] : '';
$super = $edit && !$_SESSION['opts'];
$edited_icon = 'dtree/img/question.gif';

require("lib/get_menu.php"); // takes care of database_connect()
database_connect();

$query = access_sql( $opts ) 
        . "OR ( pid = '' and pos=0 )";	// append the root

if (!$result = mysql_query($query)) { print mysql_error(); exit; }

$my = array(); $my['']=-1; // special for root
$dtree = "<a href=\"javascript: d.openAll();\" class='titel2'><u>open all</u></a> | <a href=\"javascript: d.closeAll();\" class='titel2'><u>close all</u></a><br>
    <script type='text/javascript'>
      <!--
	d = new dTree('d');
 	d.config.target='rechts';
";

 while($rij = mysql_fetch_array($result,MYSQL_ASSOC)){
	$name = $rij['name'];
	$id = $rij['id'];
	$pcode = $rij['pid']; 
	if ( $pcode != ''){ $pcode = substr( $pcode,0,strlen($pcode)-1); }
	$mypid = $rij['pid'] . $rij['pos'];
	$my [ $mypid ] = $id;
	$pid = $my[$pcode];
	if ( $edit && $rij['changed'] ){ $rij['icon']=$edited_icon;}
	$dtree .= "\td.add($id,$pid,\"$name\",\"$rij[url]\",\"$rij[title]\",\"$rij[target]\",\"$rij[icon]\",\"$rij[iconOpen]\",$rij[open])\n" ;
}
 $dtree .= "document.write(d); 
 //-->
 </script>\n";
?>

<html>
<head>
  <title>Menu Tree</title>
  <link rel="StyleSheet" href="dtree/dtree.css" type="text/css" />
  <link rel="StyleSheet" href="main.css" type="text/css" />
  <script type="text/javascript" src="dtree/dtree.js"></script>
</head>
<body>
	<div align=right><?=($super && $edit)?"<a href=menulist.php class=titel2>Edit</a>":"&nbsp;";?></div>
	<div class="dtree">
		<? echo $dtree; ?>
	</div>
</body>
</html>
