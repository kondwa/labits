<?php

require("get_menu.php"); // takes care of database_connect()
//database_connect();

/**
* sample use - at id 7, ...
* insert_node(14,'MPRS');
**/
function insert_node ( $id,$thelabel)
{
	$query = "SELECT id,pid,pos,nxt from menus
	          WHERE id = $id"; 
	if (!$result = mysql_query($query)) { print mysql_query(); exit; }
	
	$row = mysql_fetch_row($result);
    $newpid = $row[1] . $row[2] . '.';
	$newpos = $row[3];	
    
	
	$query = sprintf("INSERT menus (pid,pos,name,nxt) 
		values ('$newpid',$newpos,'%s',1)",
	    	mysql_real_escape_string($thelabel));
	
    if (!$result = mysql_query($query)) { print  mysql_error(); exit; }
    $my_id = mysql_insert_id(); // set as the last inserted id from mysql

	$query = "UPDATE menus SET url = 'page.php?id=$my_id' WHERE id = $my_id";
	    	
	if (!$result = mysql_query($query)) { print mysql_error(); exit; }
    
	
	$query = "UPDATE menus set nxt = nxt+1, kids=kids+1 WHERE id = $id";
	if (!$result = mysql_query($query)) { print  mysql_error(); exit; }
	return $my_id;
}

?>
