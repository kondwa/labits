<?
function get_goal_list(){
	$menuid=0;
	$pid="$menuid.";
	$query="SELECT id,pid,pos,name FROM menus where pid=$pid";
	if(!$result = mysql_query($query)){ print mysql_error(); exit;}
	$list="<select name=goal[] onchange=alert(this.selected.value)>\n";
	while($row = mysql_fetch_assoc($result)){
		$list .= "\t<option value='$row[id]|$row[pid],$row[pos]'>$row[name]</option>\n";
	}
	$list .= "</select>\n";
	return $list;
}

@define('UNDP_BASE', dirname(__FILE__) . '/..');
require_once UNDP_BASE . "/config.php";
database_connect();
print get_goal_list();
?>
