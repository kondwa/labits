<?php

@define('UNDP_BASE', dirname(__FILE__) . '/..');
require_once UNDP_BASE . "/config.php";
//database_connect();

	// an ngo is two steps below the root ... 
function get_ngo( $srcpid, $srcpos ){
	$desc = $srcpid.$srcpos.'%';
	$parpid = explode ('.',$srcpid); 
	// sql fetch me, my descendants and direct parent
	$sql = "( pid='$srcpid' AND pos='$srcpos' ) ";	
	$sql .= "OR ( pid like '$desc' ) ";
	$par = $parpid[0].'.'; $parpos = $parpid[1];
	$sql .= "OR ( pid ='$par' AND pos='$parpos' )"; 
	return $sql;
}

	//
	// $opts = '0.3.,1 0.1.,2';
	//
function access_sql ( $opts ){
	$root = 0;	// should really be variable - if more than 1 tree	
	$rootlike = $root . '%';
	if ( !$opts ){
	    $sql =  "SELECT * from menus WHERE " 
        	   ."pid like '$rootlike' "; 
	    return $sql;
	}
	$str = array();
	foreach ( explode(' ',$opts) as $value ){
		$pair = explode (',',$value); // $value is like 0.3.,34
		$str[] = get_ngo ( $pair[0],$pair[1] );
	}
	$sql =  "SELECT * from menus WHERE " 
	        . implode ( ' OR ', $str );
	return $sql;
}
