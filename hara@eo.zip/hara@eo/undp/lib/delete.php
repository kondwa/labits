<?

@define('UNDP_BASE', dirname(__FILE__) . '/..');
require_once UNDP_BASE . "/config.php";
//database_connect();

/**
* sample use ...
* delete_node(20);
/**/
function delete_node($id){
	$qry = "select id,nxt,name,pid,kids from menus where id=$id";
	if(!$res = mysql_query($qry)){
		print mysql_error();
		exit;
	}
	if($row = mysql_fetch_assoc($res)){
		if($row['kids'] == 0){
			#delete
			$pid=getparent($row['pid']);//get parent id
			$qry = "DELETE FROM menus WHERE id='$row[id]'";
			if(mysql_query($qry)){
				if(!mysql_query("UPDATE menus SET kids=kids-1 WHERE id=$pid")){
					print mysql_error();
					exit;
				}
				print "Node '$row[name]' deleted.";

			}else{
				print mysql_error();
			}
		}else{
			print "Parent node! -- cannot be deleted.";
		}
	}
}

function getparent($mypid){
	$id = explode(".",$mypid); array_pop($id);
	$pos = array_pop($id); array_push($id,'');
	$pid = join('.',$id);	
	$qry="SELECT id FROM menus WHERE pid='$pid' AND pos=$pos";
	if(!$res=mysql_query($qry)){
		print mysql_error();
		exit;
	}
	if($row=mysql_fetch_row($res)){
		return $row[0];
	}
}

?>
