<html>
<head>
<title>Add An Article</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<style type="text/css">
<!--
.box {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	border: 1px solid #000000;
}
-->
</style>
</head>

<body>
<?php
if(isset($_POST['save']))
{
	$title   = $_POST['title'];
	$content = $_POST['content'];
	
	if(!get_magic_quotes_gpc())
	{
		$title   = addslashes($title);
		$content = addslashes($content);
	}
	//include 'library/config.php';
	//include 'library/opendb.php';
	
	$query = "INSERT INTO news (title, content) VALUES ('$title', '$content')";
	mysql_query($query) or die('Error ,query failed');
	//include 'library/closedb.php';
	
	echo "Article '$title' added";
	}
?>
<form method="post">
  <table width="700" border="0" cellpadding="2" cellspacing="1" class="box" align="center">
    <tr> 
      <td width="100">Title</td>
      <td><input name="title" type="text" class="box" id="title"></td>
    </tr>
    <tr> 
      <td width="100">Content</td>
      <td><textarea name="content" cols="50" rows="10" class="box" id="content"></textarea></td>
    </tr>
    <tr> 
      <td width="100">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="2" align="center"><input name="save" type="submit" class="box" id="save" value="Save Article"></td>
    </tr>
  </table>
</form>
</body>
</html>
