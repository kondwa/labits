<?php 
//MODIFY THIS.

$host = "172.16.0.203";       //mostly this is localhost if mysql server is running on the same machine as script.
$user = "undpuser";        //database username here
$password = "undpuserpassword";   //database password here 
$database = "undp"; //the name of the database where you want the script installed in. 

//this are the logins for the admin part. Change them for security. 
$login = "test";  //your login for the admin section.
$pass = "1234";   //your login for the admin section.

//set the page color here.
$backcolor = "steelblue";
$smallscreen = 1;

// default sizes
$fwdth="970";
$lwdth="305";
$rwdth="665";
$thght="360";
$bhght="220";
$fhght="586"; // needs to be t+b+6

if ( $smallscreen ) {
   $fwdth="600";
   $lwdth="250";
   $rwdth="350";
   $fhght="356"; // needs to be t+b+6
   $thght="250";
   $bhght="100";
}


//NO MODIFIYNG BELOW THIS

function database_connect(){
    global $host, $database, $user, $password;

    $link = @mysql_connect("$host","$user","$password"); 
	$sql_error = mysql_error();

    if (!$link) { 
        echo "Connection with the database couldn't be made.<br>";
		echo "$sql_error"; 
        exit;
    }
  
   if (!@mysql_select_db("$database")) {; 
        echo "The database couldn't be selected.";
        exit;
    }
   return $link;
}

?>
