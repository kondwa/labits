<? 
session_start();
include_once("lib/insert.php");
database_connect();
function pop($url){
return "<a href='javascript:;' onclick='window.open(\"$url\",\"helpwin\",\"toolbar=0\")' class='titel2' title='Help on how to use this website'><u>Help</u></a>";
}
$path="about:blank";
$lpath="about:blank";
if(isset($_POST['signup'])){
	//$msg= "<div align=center><strong>Step 2 of 2.<br>Enter the Profile for Your Organisation in the Space Below</strong></div>";
	@extract($_POST);
	if($password!=$repassword){die("Password and it's confirmation do not match.");}
	$sectors=($sector)?join($sector,','):'';
	$qry="INSERT INTO organisation(name,acronym,email,website,sector) values('$name','$acronym','$email','$website','$sectors')";
	if(!mysql_query($qry)){print mysql_error(); exit;}
	$no=count($project);
	$nodename=($acronym)?$acronym:$name;
	$opts='';
	$profile="page.php?cid=$cid";
	$qry="UPDATE content SET cso=$nodename where id=$cid";
	for($i=1;isset($_POST["proj$i"]);$i++){	
		$cso=insert_node($_POST["mdg$i"],$nodename);
		$proj=insert_node($cso,$_POST["proj$i"]);
		$qry="SELECT pid,pos FROM menus WHERE id=$cso";
		if(!$res=mysql_query($qry)){ print mysql_error(); exit;}
		if($row=mysql_fetch_assoc($res)){
			$opts.=($opts)?' ':'';
			$opts.="$row[pid],$row[pos]";
		}
		if(!mysql_query("UPDATE menus SET url='$profile' WHERE id=$cso")){print mysql_error(); exit;}
	}
	$qry="INSERT INTO users(login,pass,opts) VALUES('$username','$password','$opts')";
	if(!mysql_query($qry)){ print mysql_error(); exit;}
}elseif(isset($_POST['save'])){
	$_=$_POST;
	$cid="";
	$_['text']=addslashes($_['text']);
	$_['title']=addslashes($_['title']);
	if($_['id']){
		$qry="UPDATE content SET title='$_[title]',posting_time='$_[time]',keywords='$_[keywords]',text='$_[text]',changed=1 WHERE id=$_[id]";
		if(!mysql_query($qry)){ print "1 : ".mysql_error();exit;}
		$cid=$_["id"];
			// need to evidence the change
		if($_['menuid'] != -2){
			$qry="UPDATE menus SET changed=1 WHERE id=$_[menuid]";
		}else{
			$qry="UPDATE menus SET changed=1 WHERE name='$_[cso]'";
		}
		if(!mysql_query($qry)){ print "2 : ".mysql_error();exit;}
		
	}else{
		$time=time();
		if($_['mid']){
			$qry="INSERT INTO content(title,menuid,posting_time,keywords,text,changed) VALUES('$_[title]',$_[mid],'$time','$_[keywords]','$_[text]',1)";
		}
		if(!mysql_query($qry)){ print "3 : ".mysql_error();exit;}
		
		$cid = mysql_insert_id();
		if($_['mid']){
			$qry = "UPDATE menus SET url='page.php?cid=$cid',changed=1 WHERE id=$_[mid]";
			if(!mysql_query($qry)){ "4 : ".print mysql_error();exit;}
		}
	}
	$path="page.php?cid=$cid";
}
	// for moderation acceptance
if(isset($_GET['ok'])){
	$mycid=$_GET['ok'];
	$path="page.php?cid=$mycid";
}

$edit=false;
$popup=false;
if(isset($_GET['login'])){
    $popup=true;
}
if(isset($_SESSION['loggedin'])){
    $loginlink="<a href='./login.php' class='titel2'><u>Logout</u></a>&nbsp;|&nbsp;";
    $edit=true;
}else{
	$loginlink="<a href='./login.php' class='titel2' title='Login to edit the content.'><u>Login</u></a>&nbsp;|&nbsp;";
	$loginlink.="<a href='./signup.php' class='titel2' title='Signup Your organisation'><u>Sign up</u></a>&nbsp;|&nbsp;";
}
$loginlink.=pop('help.php');
?> 
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Civil Society Database</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="./main.css" rel="stylesheet" type="text/css">
</head>
<body background="./images/int1_back.gif" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" <?=($popup)?"onLoad=\"alert('Bad login!')\"": ""; ?> >
<table width=<? echo "$fwdth"; ?> border="0" align="center" class="hoofdtabel">
  <tr>
    <td>
	  <table width="100%">
        <tr> 
          <td width="90"><img src="images/mejn-logo.gif" width="90" height="90"></td>
          <td align="center" background="./images/int1_topback.gif"><img src="images/banner.gif"></td>
          <td width="45"><img src="images/undp_logo.gif" width="45" height="90"></td>
        </tr>
        <tr>
          <td colspan="3">
            <table width="100%" bgcolor="#6699CC" class="hoofdtabel">
			<tr>
			<td height="38" colspan="2" bgcolor="#99CCCC">
			<!-- SiteSearch Google -->
<table border="0">
<form method="get" action="http://www.google.mw/custom" target="google_window">
<tr><td height="32" align="left" valign="top" nowrap="nowrap" class="titel1">

<input type="hidden" name="domains" value="www.csodatabase.mw">
</input>
<input type="text" name="q" size="15" maxlength="255" value="">
</input>
<input name="sa" type="submit" class="titel2" value="Google Search">
</input></td>
<td nowrap="nowrap"><input type="radio" name="sitesearch" value="" checked="checked"><font size="-1" color="#000000">web  </font></td>
<td nowrap="nowrap"> <font size="-1" color="#000000">
  <input type="radio" name="sitesearch" value="www.csodatabase.mw"><font size="-1" color="#000000">csodatabase.mw</font>
  <input type="hidden" name="client" value="pub-2510920133443635">
  <input type="hidden" name="forid" value="1">
  <input type="hidden" name="channel" value="7961808886">
  <input type="hidden" name="ie" value="ISO-8859-1">
  <input type="hidden" name="oe" value="ISO-8859-1">
  <input type="hidden" name="safe" value="active">
  <input type="hidden" name="cof" value="GALT:#008000;GL:1;DIV:#336699;VLC:663399;AH:center;BGC:FFFFFF;LBGC:336699;ALC:0000FF;LC:0000FF;T:000000;GFNT:0000FF;GIMP:0000FF;FORID:1;">
  <input type="hidden" name="hl" value="en">
  </font></font></td>
</tr></form></table>

<!-- SiteSearch Google -->			      
			
			  <!--div align="center">
			  	<form name="sfrm">
				<!--input name="q" type="text" size=40>&nbsp;
				<input type="button" class="titel3" onClick="goSearch('web')" value="Google Search"-->
		        </div--></td>
			<td width="24%" bgcolor="#99CCCC"><?=$loginlink;?></td>
			</tr>
 </table></td>
        </tr>
      </table>
	  <table width="<?=$fwdth;?>" border="0">
  		<tr>
   		 <td align="left" valign="top"><iframe src="./menu.php" width="<?=$lwdth;?>" height="<?=($edit) ? $thght : $fhght;?>" id="links" name="links" class="iframe" scrolling="auto" frameborder="0"></iframe></td>
   		 <td <?=($edit)? "rowspan=2" : ''; ?> valign="top" align="right"><iframe src="<?=$path;?>" width="<?=$rwdth;?>" height="<?=$fhght;?>" id="rechts" name="rechts" class="iframe" scrolling="auto" frameborder="0"></iframe></td>
	    </tr>
		<?=($edit)?
		 "<tr>
		 <td valign=top align=left>
		 <iframe src=\"$lpath\" width=$lwdth height=$bhght id=onder name=onder class=iframe scrolling=auto frameborder=0></iframe>
		 </td>
		 </tr>" : '';
		?>
	  </table>	</td>
  </tr>
</table>
<p align="center">&copy; <a href="http://www.eomw.net">Epsilon &amp; Omega</a> 2006 </p>
</body>
</html>

