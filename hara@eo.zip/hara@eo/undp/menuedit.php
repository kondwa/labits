<?php
    include("config.php");
	 $id=$pid=$pos=$name=$url=$title=$target=$icon=$iconOpen=$open=$nxt=$cid=$kids='';
    database_connect();

if($_GET){
	if($_GET['id']){
		$mid=$_GET['id'];
		$qry="SELECT * FROM menus WHERE id=$mid";
		if(!$res=mysql_query($qry)){
			print mysql_error();
		exit;
		}
		if($row=mysql_fetch_assoc($res)){
			$id=$row['id'];
			$pid=$row['pid'];
			$pos=$row['pos'];
			$name=$row['name'];
			$url=$row['url'];
			$title=$row['title'];
			$target=$row['target'];
			$icon=$row['icon'];
			$iconOpen=$row['iconOpen'];
			$open=$row['open'];
			$nxt=$row['nxt'];
			$cid=$row['cid'];
			$kids=$row['kids'];
		}	
	}
}
if(isset($_POST['save'])){
	$nodeid=$_POST['id'];
	$name=$_POST['name'];
	$title=$_POST['title'];
	$url=$_POST['url'];
	$urlquery=($_POST['reset'])?",url='page.php?id=$nodeid'":"url='$url'";
	$query="UPDATE menus SET name='$name',title='$title',$urlquery WHERE id=$nodeid";
	if(!mysql_query($query)){ print mysql_error(); exit;}	
}
?>
<html>
<head>
</head>
<body>
<table>
<form method=post action=<?=$PHP_SELF;?>>
  <tr>
    <td>ID:</td>
    <td><input type=hidden name=id value="<?=$id;?>"><?=$id . ": " . $pid . $pos?></td>
    <td>&nbsp;&nbsp;&nbsp;</td>
    <td>URL:</td>
    <td><input name=url value="<?=$url;?>"><label title="Resets the url to the default url"><input type=checkbox value=on name=reset>Reset</label></td>
  </tr>
  <tr>
    <td>Name:</td>
    <td><input type="text" name="name" value="<?=$name;?>" size="10"></td>
    <td>&nbsp;&nbsp; </td>
    <td>title</td>
    <td><input type="text" name="title" value="<?=$title;?>" size="10"></td>
  </tr>
  <tr>
    <td align="right" colspan="5"><input type="submit" value="save" name="save"><input type="reset" value="reset"></td>
  </tr>
</form>
</table>

