<?
require_once ("config.php");
database_connect();

$users = array();
$opts = array();
$status = array();
// fetch users
if(!$result=mysql_query("SELECT login,pass,opts,status FROM users"))
   { print mysql_error(); exit;}

while($entry = mysql_fetch_array($result,MYSQL_ASSOC)){
	$username = $entry['login'];
	$users[ $username ] = $entry['pass'];
	$opts [ $username ] = $entry['opts'];
	$status [ $username ] = $entry['status'];
}

session_start();

$formlogin= isset($_POST['formlogin']) ? $_POST['formlogin'] : '';
$formpass= isset($_POST['formpass']) ? $_POST['formpass'] : '';

//if ($formpass == $pass && $formlogin == $login) {
if (isset( $users[ $formlogin ]) 
	&& $status[ $formlogin ] 
	&& $formpass == $users[ $formlogin ] ) {
    $_SESSION["loggedin"]=true;
    $_SESSION["opts"]=$opts[ $formlogin ];
    header("Location: index.php");
}elseif(isset($_SESSION['loggedin'])){
    session_destroy();
    header("Location: index.php");
}elseif($formpass != '' && $formlogin != ''){
    header("Location: index.php?login=failed");
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Login</title>
	<link href="main.css" rel="stylesheet" type="text/css">
    
</head>

<body style="font-family: tahoma;">
<p>&nbsp;</p>
<table width="669" height="55" border="0">
  <tr>
    <td>&nbsp;</td>
    <td><div align="center"><strong>CSO Database Login </strong><br>
        <em>Please Enter your username and password to edit your web pages </em></div></td>
    <td>  
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="110">&nbsp;</td>
    <td width="427"><form action="login.php" method="post" name="frm">
      <div align="center">
        <table cellspacing="4" cellpadding="4" style="border-bottom-width: thin; border-left-width: thin; border-right-width: thin; border-top-width: thin; border-style: dotted; border-color: red;">
            <tr>
              <td rowspan=2><img src='images/security.gif' title='please login'></td>
              <td>username</td>
              <td><input type="text" name="formlogin" class="cssborder"></td>
            </tr>
            <tr>
              <td>password</td>
              <td><input type="password" name="formpass" class="cssborder"></td>
            </tr>
              </table>
        <br>
          <input name="submit" type="submit" value="login" >
      </div>
    </form>      <p align="center"></td></Br>
    <td width="110">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
</body>
</html>
