<?php
session_start(); 
$edit = isset($_SESSION['loggedin']);
$super = $edit && !$_SESSION['opts']; // opts is the empty string

require_once ("config.php");
$cacheDir  = dirname(__FILE__) . '/cache/';

if (isset($_GET['id'])) {
	$cacheFile = $cacheDir . '_' . $_GET['id'] . '.html';
} elseif (isset($_GET['cid'])) {
	$cacheFile = $cacheDir . '_' . $_GET['cid'] . '.htm';
} else {
	$cacheFile = $cacheDir . 'index.html';
}	

if (!$edit && file_exists($cacheFile))
{
	header("Content-Type: text/html");
	readfile($cacheFile);
	exit;
}

database_connect();

$title = '';
$content = '';
$path='';	// need to initialise this
$cid=0;		// and this one too ...

if ( isset($_GET) ) {
	if(isset( $_GET['id'] ) ){
		$id = $_GET['id'];
		#$query = "select cid,name,pid,pos,changed from menus where id=$id";
		$query = "select name,pid,pos,changed from menus where id=$id";
		if(!$res = mysql_query($query)){
			print mysql_error();
			exit;
		}	
		if($row = mysql_fetch_assoc($res)){
			#$cid = $row['cid'];
			$name = $row['name'];
			$pid=$row['pid'];
			$pos=$row['pos'];
			$changed = $row['changed'];
			$cid='';
			$mid='';
			$title = "Blank Page";
			$content = "Login to create the page for $name";
		}
		$path=getpath($id);
	}elseif( isset($_GET['cid']) ){
		$cid=$_GET['cid'];
		$query = "select * from content where id=$cid";
		if(!$res = mysql_query($query)){
			print mysql_error();
			exit;
		}	
		if($row = mysql_fetch_assoc($res)){
			$cid=$row['id'];
			$mid=$row['menuid'];
			$title = $row['title'];
			$changed = $row['changed'];
			$content = $row['text'];
		}else{
			$cid='';
			$mid='';
			$title = "Blank Page";
			$content = "Login and click on create";
		}
		$path=getpath($mid);
	}
} else {
	$title = "<h2>Welcome!</h2>";
	$content = "This is start page";
	$page = "Home";
}
if($cid && $edit){ 
	$link = ($super && $changed) ? "<a class=titel2 href =\"accept.php?id=$cid\" target=_top>Accept</a>&nbsp; | &nbsp;" : '';
	$link .= "<a class=titel2 href=\"edit.php?id=$cid\" target=_top>Edit</a>"; 
} elseif ($edit) {
	$link = "<a href=\"edit.php?mid=$id\" class=titel2 target=_top>Create</a>";
}else{
	$link = "&nbsp;";
}

function getpath($mid){
	$path='';
	if($mid!=-2){
		if(!$res=mysql_query("SELECT pid,pos FROM menus WHERE id=$mid")){ print mysql_error(); exit;}
		if($row=mysql_fetch_assoc($res)){
			$pid=$row['pid'];
			$pos=$row['pos'];
			$ps = explode('.',$pid);
			array_pop($ps);
			while($ps){
				$pos=end($ps);
				array_pop($ps);
				$p = join('.',$ps) . '.';
				if(!$res=mysql_query("SELECT name FROM menus WHERE pid='$p' AND pos=$pos")){
					print mysql_error();
					exit;
				}
				if($row=mysql_fetch_assoc($res)){
					//$name=(strlen($row['name'])>15)? substr($row['name'],0,12)."...":$row['name'];
					$path = "$row[name] &raquo; " . $path;
				}
			}
		}
		return $path;
	}
}
ob_start();
?>
<html>
<head>
<link rel="StyleSheet" href="main.css" type="text/css" />
</head>
<body>
<table width=100%><tr><td align=left><h2 class=titel2><?=$path ."<font color=red><u>$title</u></font>";?></h2></td>
<td align=right><?=$link;?></td></tr></table>
<br>
<?=$content;?>
</body>
</html>
<?
	$buffer=ob_get_contents();

	ob_end_flush();	
	if ( $edit ) { exit;} // we _don't_ write to cachefile !!
	$fp = fopen($cacheFile,'w');
	fwrite($fp,$buffer);
	fclose($fp);
?>
