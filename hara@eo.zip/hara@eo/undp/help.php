<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body background="./images/int1_back.gif">
<table width=<? echo "$fwdth"; ?> border="0" align="center" class="hoofdtabel">
  <tr>
    <td><h3 align="center">CSO Database - How to use this site </h3></td>
  </tr>
  <tr>
    <td><h4>Signing up </h4>
      <p>In order to have information about you organisation and the studies/projects your organisation has been working on, you will need to sign up. Here is how you do it:</p>
      <ul>
        <li>On the home page click <a href="./signup.php" class="titel2">sign up</a></li>
        <li>Enter Your Organisation Profile Which includes the title of the profile(<em>eg. 'MEJN Profile' for the organisation MEJN</em>), a brief description and contact details</li>
        <li> </li>
      </ul></td>
  </tr>
</table>
</body>
</html>
