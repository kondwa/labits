<? require_once("lib.php"); $data=getData(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..: CheckBook :..</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="90%" align="center">
<form method="post">
  <tr>
    <td width="100">&nbsp;</td>
    <td align="center"><h1>CheckBook</h1></td>
    <td width="100">&nbsp;</td>
  </tr>
  <tr>
    <td width="100">&nbsp;</td>
    <td>&nbsp;</td>
    <td width="100">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td align="center">
		<?
			print_r($data);
			switch($do){
				default:
					form($data);
				break;			
			}
		?>
	</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td width="100">&nbsp;</td>
    <td><table align="center">
      <tr class="theading">
        <td width="80">Date</td>
        <td width="200">Description</td>
        <td width="60">Chq. # </td>
        <td width="100" colspan="2">Amount</td>
        <td width="30" align="center">Cld</td>
        <td width="30" colspan="2" align="center">Balance</td>
      </tr>
      <tr class="trow">
        <td width="80" align="center">01-02-2007</td>
        <td width="200">Payed to Silver Leaf </td>
        <td width="60" align="center">000020</td>
        <td width="5"><strong>K</strong></td>
        <td align="right">100,000.00</td>
        <td width="30" align="center"><img src="img/yes.gif" alt="yes"/></td>
        <td width="5" align="center"><strong>K</strong></td>
        <td align="right">1,900,000.00</td>
      </tr>
      <tr class="trow">
        <td width="80" align="center">02-02-2007</td>
        <td>From Ministry of trade </td>
        <td width="60" align="center">100023</td>
        <td width="5"><strong>K</strong></td>
        <td align="right">90,000.00</td>
        <td width="30" align="center"><img src="img/no.gif" alt="no" /></td>
        <td width="5" align="center"><strong>K</strong></td>
        <td align="right">1,900,000.00</td>
      </tr>
    </table></td>
    <td width="100">&nbsp;</td>
  </tr>
</form>
</table>
</body>
</html>
