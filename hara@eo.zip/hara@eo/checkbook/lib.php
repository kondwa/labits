<link href="style.css" rel="stylesheet" type="text/css">
<?
	$DB['host']='localhost';
	$DB['user']='cbuser';
	$DB['pass']='cbpass';
	$DB['name']='checkbook';
	function dbOpen(){
		global $DB,$dbh;
		$dbh=mysql_connect($DB['host'],$DB['user'],$DB['pass']) or die(mysql_error());
		mysql_select_db($DB['name']);
	}
	function dbClose(){
		global $dbh;
		mysql_close($dbh);
	}
	function mkdate($n,$f,$d){
		//get n=name,f=('y'|'m'|'d'),d=default
		preg_match("/(?P<y>[12]\\d{3})-(?P<m>[01]\\d)-(?P<d>[0123]\\d)/",$d, $d);
		$s=array('y'=>date('Y')-2,'m'=>1,'d'=>1);
		$e=array('y'=>date('Y')+5,'m'=>12,'d'=>31);
		$htm="<select name=$n class=inputbox><option></option>";
		for($i=$s[$f]; $i<=$e[$f]; $i++){
			$v=($i<10)?"0$i":$i;
			$htm .=($v == $d[$f])?
				"<option selected=selected>$v</option>":
				"<option>$v</option>";
		}
		$htm.="</select>\r\n";
		return $htm;
	}
	function dbData($id){
		return array();
	}
	function getData(){
		return $_POST + $_GET;
	}
	function form(){
		global $data;
		@extract($data);
		@extract(dbData($id));
		$todo=($id)?"save":"add";
		?>
		<input type="hidden" name="transctype" value="<?=$transctype;?>">
		<input type="hidden" name="id" value="<?=$id;?>">
		<table>
    	  <tr class="theading">
        	<td>Date</td>
	        <td>Transaction</td>
	        <td>Description</td>
    	    <td>Chq. # </td>
        	<td>Amount</td>
	        <td>action</td>
    	  </tr>
	      <tr class="trow">
    		 <td><input name="transcdate" type="text" class="input" value="<?=$transcdate;?>" size="10"></td>
        	 <td><select name="select" class="input">
        	   <option value="in">Deposit</option>
        	   <option value="out">Withdraw</option>
      	     </select>
        	 </td>
       	    <td><input name="description" type="text" class="input" value="<?=$description;?>"></td>
	        <td><input name="chequeno" type="text" class="input" value="<?=$chequeno;?>" size="8"></td>
    	    <td><input name="amount" type="text" class="input" value="<?=$amount;?>" size="10"></td>
        	<td>
				<input name="do" type="submit" class="button" value="<?=$todo;?>">
				<? if($do=='add'){ ?>
				<input name="do" type="submit" class="button" id="do" value="drop">
				<? } ?>
				<input name="do" type="submit" class="button" value="cancel">			</td>
   	      </tr>
		</table>
	<?
	}
?>