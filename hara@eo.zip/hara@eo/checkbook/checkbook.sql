CREATE DATABASE checkbook;
GRANT ALL ON checkbook.* TO cbuser@localhost IDENTIFIED BY 'cbpass';
USE checkbook;
CREATE TABLE `book`(
	`id` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`transcdate` DATE DEFAULT NOW(),
	`description` blob DEFAULT '',
	`chequeno` varchar(8) DEFAULT '',
	`transctype` ENUM('in','out') DEFAULT 'in',
	`amount` DOUBLE(10,2),
	`cld` ENUM('yes','no') DEFAULT 'no'
);